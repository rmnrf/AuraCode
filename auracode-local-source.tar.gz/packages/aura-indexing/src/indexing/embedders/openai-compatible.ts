import { OpenAI } from "openai"
import type { IEmbedder, EmbeddingResponse, EmbedderInfo } from "../interfaces/embedder"
import {
  MAX_BATCH_TOKENS,
  MAX_ITEM_TOKENS,
  MAX_BATCH_RETRIES as MAX_RETRIES,
  INITIAL_RETRY_DELAY_MS as INITIAL_DELAY_MS,
  REMOTE_EMBEDDER_VALIDATION_MAX_RETRIES,
  REMOTE_EMBEDDER_VALIDATION_TIMEOUT_MS,
} from "../constants"
import { getDefaultModelId, getModelQueryPrefix } from "../model-registry"
import {
  withValidationErrorHandling,
  extractStatusCode,
  type HttpError,
  formatEmbeddingError,
} from "../shared/validation-helpers"
import { applyQueryPrefix, embedBatches } from "../shared/embedder-helpers"
import {
  createRateLimitState,
  getRateLimitDelay,
  projectEmbeddingResponse,
  updateRateLimitState,
  waitForRateLimit,
} from "../shared/openai-compatible-helpers"
import { Log } from "../../util/log"

const log = Log.create({ service: "embedder-openai-compatible" })

interface EmbeddingItem {
  embedding: string | number[]
  [key: string]: any
}

interface OpenAIEmbeddingResponse {
  data: EmbeddingItem[]
  usage?: {
    prompt_tokens?: number
    total_tokens?: number
  }
}

type OpenAICompatibleOptions = {
  headers?: Record<string, string>
  dimensions?: number
}

/**
 * OpenAI Compatible implementation of the embedder interface with batching and rate limiting.
 * This embedder allows using any OpenAI-compatible API endpoint by specifying a custom baseURL.
 */

export class OpenAICompatibleEmbedder implements IEmbedder {
  private embeddingsClient: OpenAI
  private readonly defaultModelId: string
  private readonly baseUrl: string
  private readonly apiKey?: string
  private readonly isFullUrl: boolean
  private readonly maxItemTokens: number
  private readonly headers: Record<string, string>
  private readonly dimensions?: number
  private readonly omitted = new Set<string>()

  // Global rate limiting state shared across all instances
  private static globalRateLimitState = createRateLimitState()

  /**
   * Creates a new OpenAI Compatible embedder
   * @param baseUrl The base URL for the OpenAI-compatible API endpoint
   * @param apiKey Optional API key for authentication
   * @param modelId Optional model identifier (defaults to "text-embedding-3-small")
   * @param maxItemTokens Optional maximum tokens per item (defaults to MAX_ITEM_TOKENS)
   */
  constructor(
    baseUrl: string,
    apiKey?: string,
    modelId?: string,
    maxItemTokens?: number,
    options: OpenAICompatibleOptions = {},
  ) {
    if (!baseUrl) {
      throw new Error("Base URL is required for OpenAI-compatible embedder")
    }

    this.baseUrl = baseUrl
    this.apiKey = apiKey?.trim() || undefined

    const defaults = new Headers(options.headers)
    this.embeddingsClient = new OpenAI({
      baseURL: baseUrl,
      apiKey: this.apiKey ?? "EMPTY",
      defaultHeaders: options.headers,
      fetch: this.apiKey
        ? undefined
        : async (input, init) => {
            const headers = new Headers(init?.headers)
            if (!defaults.has("authorization")) headers.delete("authorization")
            if (!defaults.has("api-key")) headers.delete("api-key")
            return globalThis.fetch(input, { ...init, headers: Object.fromEntries(headers) })
          },
    })

    this.defaultModelId = modelId || getDefaultModelId("openai-compatible")
    // Cache the URL type check for performance
    this.isFullUrl = this.isFullEndpointUrl(baseUrl)
    this.maxItemTokens = maxItemTokens || MAX_ITEM_TOKENS
    this.headers = options.headers ?? {}
    this.dimensions = options.dimensions
  }

  /**
   * Creates embeddings for the given texts with batching and rate limiting
   * @param texts Array of text strings to embed
   * @param model Optional model identifier
   * @returns Promise resolving to embedding response
   */
  async createEmbeddings(texts: string[], model?: string): Promise<EmbeddingResponse> {
    const modelToUse = model || this.defaultModelId

    // Apply model-specific query prefix if required
    const processedTexts = applyQueryPrefix(
      texts,
      getModelQueryPrefix("openai-compatible", modelToUse),
      MAX_ITEM_TOKENS,
      (index, tokens) =>
        log.warn(`Text at index ${index} with prefix exceeds token limit (${tokens} > ${MAX_ITEM_TOKENS})`),
    )

    return embedBatches(
      processedTexts,
      this.maxItemTokens,
      MAX_BATCH_TOKENS,
      (batch) => this._embedBatchWithRetries(batch, modelToUse),
      (index, tokens) => log.warn(`Text at index ${index} exceeds token limit (${tokens} > ${this.maxItemTokens})`),
    )
  }

  /**
   * Determines if the provided URL is a full endpoint URL or a base URL that needs the endpoint appended by the SDK.
   * Uses smart pattern matching for known providers while accepting we can't cover all possible patterns.
   * @param url The URL to check
   * @returns true if it's a full endpoint URL, false if it's a base URL
   */
  private isFullEndpointUrl(url: string): boolean {
    // Known patterns for major providers
    const patterns = [
      // Azure OpenAI: /deployments/{deployment-name}/embeddings
      /\/deployments\/[^\/]+\/embeddings(\?|$)/,
      // Azure Databricks: /serving-endpoints/{endpoint-name}/invocations
      /\/serving-endpoints\/[^\/]+\/invocations(\?|$)/,
      // Direct endpoints: ends with /embeddings (before query params)
      /\/embeddings(\?|$)/,
      // Some providers use /embed instead of /embeddings
      /\/embed(\?|$)/,
    ]

    return patterns.some((pattern) => pattern.test(url))
  }

  /**
   * Makes a direct HTTP request to the embeddings endpoint
   * Used when the user provides a full endpoint URL (e.g., Azure OpenAI with query parameters)
   * @param url The full endpoint URL
   * @param batchTexts Array of texts to embed
   * @param model Model identifier to use
   * @param dimensions Optional embedding dimensions to request
   * @param signal Optional abort signal
   * @returns Promise resolving to OpenAI-compatible response
   */
  private async makeDirectEmbeddingRequest(
    url: string,
    batchTexts: string[],
    model: string,
    dimensions: number | undefined,
    signal?: AbortSignal,
  ): Promise<OpenAIEmbeddingResponse> {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...this.headers,
        ...(this.apiKey
          ? {
              "api-key": this.apiKey,
              Authorization: `Bearer ${this.apiKey}`,
            }
          : {}),
      },
      body: JSON.stringify({
        input: batchTexts,
        model: model,
        encoding_format: "base64",
        ...(dimensions !== undefined ? { dimensions } : {}),
      }),
      signal,
    })

    if (!response || !response.ok) {
      const status = response?.status || 0
      let errorText = "No response"
      try {
        if (response && typeof response.text === "function") {
          errorText = await response.text()
        } else if (response) {
          errorText = `Error ${status}`
        }
      } catch {
        // Ignore text parsing errors
        errorText = `Error ${status}`
      }
      const error = new Error(`HTTP ${status}: ${errorText}`) as HttpError
      error.status = status || response?.status || 0
      throw error
    }

    try {
      return (await response.json()) as OpenAIEmbeddingResponse
    } catch (e) {
      const error = new Error(`Failed to parse response JSON`) as HttpError
      error.status = response.status
      throw error
    }
  }

  private async request(
    texts: string[],
    model: string,
    options: { signal?: AbortSignal; timeout?: number; maxRetries?: number } = {},
  ): Promise<{
    response: OpenAIEmbeddingResponse
    projected?: { embeddings: number[][]; usage: { promptTokens: number; totalTokens: number } }
  }> {
    const send = async (dimensions: number | undefined): Promise<OpenAIEmbeddingResponse> => {
      if (this.isFullUrl) {
        return this.makeDirectEmbeddingRequest(this.baseUrl, texts, model, dimensions, options.signal)
      }
      const body = {
        input: texts,
        model: model,
        // OpenAI package (as of v4.78.1) has a parsing issue that truncates embedding dimensions to 256
        // when processing numeric arrays, which breaks compatibility with models using larger dimensions.
        // By requesting base64 encoding, we bypass the package's parser and handle decoding ourselves.
        encoding_format: "base64" as const,
        ...(dimensions !== undefined ? { dimensions } : {}),
      }
      if (options.timeout === undefined && options.maxRetries === undefined) {
        return this.embeddingsClient.embeddings.create(body)
      }
      return this.embeddingsClient.embeddings.create(body, {
        timeout: options.timeout,
        maxRetries: options.maxRetries,
      })
    }

    const check = (response: OpenAIEmbeddingResponse) => {
      // Guard the shape before decoding. A 200 response with an error body has no
      // data, so decoding it first would throw a raw TypeError. Do not throw here
      // either: validation reads response.error for that case, and the batch caller
      // reports the missing data when it needs the vectors.
      const hasData = Array.isArray(response?.data)
      const projected = hasData ? projectEmbeddingResponse(response) : undefined
      if (this.dimensions !== undefined && projected) {
        if (response.data.length !== texts.length) {
          throw new Error("Invalid response from embedding endpoint")
        }
        for (const vector of projected.embeddings) {
          if (Array.isArray(vector) && vector.length === this.dimensions) continue
          throw new Error(
            `Embedding endpoint returned ${Array.isArray(vector) ? vector.length : 0} dimensions, but ${this.dimensions} are configured. ` +
              "Set the configured dimension to match the model output or use an endpoint that supports the requested dimensions.",
          )
        }
      }
      return { response, projected }
    }
    const dimensions = this.omitted.has(model) ? undefined : this.dimensions

    try {
      return check(await send(dimensions))
    } catch (error) {
      const status = extractStatusCode(error)
      const param = error instanceof Error && "param" in error && error.param === "dimensions"
      if (
        dimensions === undefined ||
        (status !== 400 && status !== 422) ||
        !(error instanceof Error) ||
        (!param && !/\bdimensions\b/i.test(error.message)) ||
        !/unsupported|not support|not allowed|not permitted|unknown|unrecognized|unexpected|extra|does not|doesn't/i.test(
          error.message,
        )
      ) {
        throw error
      }

      log.warn("Embedding endpoint rejected the dimensions parameter, retrying without it")
      // Keep the configured store size. Omit dimensions only after a matching response succeeds.
      const result = check(await send(undefined))
      if (result.projected) this.omitted.add(model)
      return result
    }
  }

  /**
   * Helper method to handle batch embedding with retries and exponential backoff
   * @param batchTexts Array of texts to embed in this batch
   * @param model Model identifier to use
   * @returns Promise resolving to embeddings and usage statistics
   */
  private async _embedBatchWithRetries(
    batchTexts: string[],
    model: string,
  ): Promise<{ embeddings: number[][]; usage: { promptTokens: number; totalTokens: number } }> {
    for (let attempts = 0; attempts < MAX_RETRIES; attempts++) {
      // Check global rate limit before attempting request
      await this.waitForGlobalRateLimit()

      try {
        const { projected } = await this.request(batchTexts, model)
        if (!projected) throw new Error("Invalid response from embedding endpoint")

        return projected
      } catch (error) {
        log.error("OpenAI Compatible embedder batch error", {
          err: error instanceof Error ? error.message : String(error),
          location: "OpenAICompatibleEmbedder:_embedBatchWithRetries",
          attempt: attempts + 1,
        })

        const hasMoreAttempts = attempts < MAX_RETRIES - 1

        // Check if it's a rate limit error
        const httpError = error as HttpError
        if (httpError?.status === 429) {
          // Update global rate limit state
          await this.updateGlobalRateLimitState(httpError)

          if (hasMoreAttempts) {
            // Calculate delay based on global rate limit state
            const baseDelay = INITIAL_DELAY_MS * Math.pow(2, attempts)
            const globalDelay = await this.getGlobalRateLimitDelay()
            const delayMs = Math.max(baseDelay, globalDelay)

            log.warn(`Rate limit hit, retrying in ${delayMs}ms (attempt ${attempts + 1}/${MAX_RETRIES})`)
            await new Promise((resolve) => setTimeout(resolve, delayMs))
            continue
          }
        }

        // Format and throw the error
        throw formatEmbeddingError(error, MAX_RETRIES)
      }
    }

    throw new Error(`Embedding failed after ${MAX_RETRIES} attempts`)
  }

  /**
   * Validates the OpenAI-compatible embedder configuration by testing endpoint connectivity and API key
   * @returns Promise resolving to validation result with success status and optional error message
   */
  async validateConfiguration(): Promise<{ valid: boolean; error?: string }> {
    return withValidationErrorHandling(async () => {
      try {
        // Test with a minimal embedding request
        const testTexts = ["test"]
        const modelToUse = this.defaultModelId
        let response: OpenAIEmbeddingResponse

        // Abort full-endpoint requests on timeout. Base URLs get an SDK timeout instead.
        const ctl = this.isFullUrl ? new AbortController() : undefined
        const timer = ctl ? setTimeout(() => ctl.abort(), REMOTE_EMBEDDER_VALIDATION_TIMEOUT_MS) : undefined

        try {
          const result = await this.request(testTexts, modelToUse, {
            signal: ctl?.signal,
            timeout: REMOTE_EMBEDDER_VALIDATION_TIMEOUT_MS,
            maxRetries: REMOTE_EMBEDDER_VALIDATION_MAX_RETRIES,
          })
          response = result.response
        } finally {
          if (timer) clearTimeout(timer)
        }

        const error = (response as { error?: string | { message?: string } }).error
        const message = typeof error === "string" ? error : error?.message
        if (message) return { valid: false, error: message }

        // Check if we got a valid response
        if (!response?.data || response.data.length === 0) {
          return {
            valid: false,
            error: "Invalid response from embedding endpoint",
          }
        }

        return { valid: true }
      } catch (error) {
        log.error("OpenAI Compatible embedder validation error", {
          err: error instanceof Error ? error.message : String(error),
          location: "OpenAICompatibleEmbedder:validateConfiguration",
        })
        throw error
      }
    }, "openai-compatible")
  }

  /**
   * Returns information about this embedder
   */
  get embedderInfo(): EmbedderInfo {
    return {
      name: "openai-compatible",
    }
  }

  /**
   * Waits if there's an active global rate limit
   */
  private async waitForGlobalRateLimit(): Promise<void> {
    return waitForRateLimit(OpenAICompatibleEmbedder.globalRateLimitState)
  }

  /**
   * Updates global rate limit state when a 429 error occurs
   */
  private async updateGlobalRateLimitState(_error: HttpError): Promise<void> {
    return updateRateLimitState(OpenAICompatibleEmbedder.globalRateLimitState)
  }

  /**
   * Gets the current global rate limit delay
   */
  private async getGlobalRateLimitDelay(): Promise<number> {
    return getRateLimitDelay(OpenAICompatibleEmbedder.globalRateLimitState)
  }
}
