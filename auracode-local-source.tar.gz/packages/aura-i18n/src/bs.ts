export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "Za više statistika korištenja, koristite ",
  "provider.connect.auraGateway.byok.link": "BYOK putem Aura's Gateway",
  "provider.connect.auraGateway.byok.suffix": ".",

  // Provider settings translations
  "settings.providers.group.recommended": "Preporučeno",
  "settings.providers.note.aura": "Pristup za 500+ AI modela",
  "settings.providers.note.opencode": "Odabrani modeli uključujući Claude, GPT, Gemini i još mnogo toga",
  "settings.providers.note.anthropic": "Direktan pristup Claude modelima, uključujući Pro i Max",
  "settings.providers.note.deepseek": "DeepSeek modeli za zadatke rezonovanja i programiranja",
  "settings.providers.note.copilot": "Claude modeli za pomoć pri programiranju",
  "settings.providers.note.openai": "GPT i Codex modeli uz API ključ ili ChatGPT prijavu",
  "settings.providers.note.google": "Gemini modeli za brze, strukturirane odgovore",
  "settings.providers.note.openrouter": "Pristup svim podržanim modelima od jednog provajdera",
  "settings.providers.note.vercel": "Objedinjen pristup AI modelima s pametnim usmjeravanjem",

  // Desktop translations
  "desktop.menu.reloadWebview": "Ponovno učitavanje webview-a",
  "desktop.updater.installFailed.message": "Neuspjelo instaliranje ažuriranja",
  "desktop.cli.installed.message": "CLI je instaliran u {{path}}\n\nRestartuj terminal da bi koristio komandu 'aura'.",

  // Reasoning block label
  "ui.reasoning.label": "Rezonovanje",

  // Marketplace
  "marketplace.card.installed": "Instalirano",
  "marketplace.card.install": "Instaliraj",
  "marketplace.card.remove": "Ukloni",
  "marketplace.card.removeScope": "Ukloni ({{scope}})",
  "marketplace.card.showMore": "Prikaži više",
  "marketplace.card.showLess": "Prikaži manje",
  "marketplace.install.title": "Instaliraj {{name}}",
  "marketplace.install.scope": "Opseg",
  "marketplace.install.scope.project": "Projekat",
  "marketplace.install.scope.global": "Globalno",
  "marketplace.install.scope.project.description":
    "Samo ovaj projekat. Instalirane datoteke mogu se dodati u kontrolu verzija i dijeliti s vašim timom.",
  "marketplace.install.scope.global.description":
    "Svi projekti na ovom računaru. Čuva se u vašoj korisničkoj konfiguraciji.",
  "marketplace.install.destination": "Odredište instalacije",
  "marketplace.install.includedSkills": "Uključene vještine",
  "marketplace.install.about.mcp":
    "MCP server pruža Kilu dodatne alate za rad s vanjskim servisima ili lokalnim programima.",
  "marketplace.install.about.agent": "Agent dodaje višekratnu ulogu s vlastitim uputama i dozvolama.",
  "marketplace.install.about.skill":
    "Vještina dodaje upute i resurse za određene zadatke koje Aura može učitati kada su potrebni.",
  "marketplace.install.mcp.warning":
    "MCP serveri mogu pokretati lokalne naredbe ili se povezivati s vanjskim servisima. Aura će zatražiti dozvolu prije korištenja njihovih alata, osim ako vaše dozvole to automatski dopuštaju.",
  "marketplace.install.project.warning":
    "Datoteke projekta mogu se dodati u kontrolu verzija. Ne čuvajte tajne ovdje osim ako konfiguracija upućuje na varijablu okruženja.",
  "marketplace.install.learnMore": "Saznajte kako funkcionišu instalacije s Marketplacea",
  "marketplace.install.learnMcp": "Saznajte više o MCP-u",
  "marketplace.install.about.plugin":
    "Dodatak dodaje prilagođene alate i integracije u Aura. Dodaci se izvršavaju sa svim dozvolama.",
  "marketplace.install.plugin.warning":
    "Dodaci izvršavaju kod sa svim dozvolama. Mogu čitati i mijenjati vaše datoteke, pokretati naredbe i pristupati vašim pristupnim podacima i mreži. Instalirajte samo dodatke kojima vjerujete.",
  "marketplace.intro": "Instalirajte višekratne agente, vještine, MCP alate i dodatke za jedan ili sve projekte.",
  "marketplace.intro.learnMore": "O Marketplaceu",
  "marketplace.install.prerequisites": "Preduslovi",
  "marketplace.install.installing": "Instalacija...",
  "marketplace.install.cancel": "Otkaži",
  "marketplace.install.success": "Uspješno instalirano!",
  "marketplace.install.failed": "Instalacija nije uspjela",
  "marketplace.install.done": "Završeno",
  "marketplace.install.close": "Zatvori",
  "marketplace.install.mcp.signIn.message": "{{name}} je instaliran, ali zahtijeva prijavu prije nego što se njegovi alati mogu koristiti.",
  "marketplace.install.mcp.signIn.button": "Prijava",
  "marketplace.install.mcp.signIn.waiting": "Čekanje na prijavu putem preglednika…",
  "marketplace.install.mcp.signIn.cancel": "Otkaži",
  "marketplace.install.mcp.signIn.skip": "Kasnije",
  "marketplace.install.mcp.signIn.success": "Prijavljeni ste na {{name}}.",
  "marketplace.install.mcp.signIn.failed": "Prijava na {{name}} nije uspjela.",
  "marketplace.remove.title": "Ukloniti {{name}}?",
  "marketplace.remove.confirm":
    "Jeste li sigurni da želite ukloniti ovaj {{type}}? Ovo će ga ukloniti iz vaše {{scope}} konfiguracije.",
  "marketplace.remove.cancel": "Otkaži",
  "marketplace.remove.mcp.skills":
    "Ovo uklanja i prateće vještine koje pripadaju ovoj instalaciji. Samostalno instalirane vještine se zadržavaju.",
  "marketplace.remove.confirm.button": "Ukloni",
  "marketplace.search": "Pretraži...",
  "marketplace.filter.all": "Sve stavke",
  "marketplace.filter.notInstalled": "Nije instalirano",
  "marketplace.filter.relevant": "Relevantno za moj radni prostor",
  "marketplace.empty": "Nema pronađenih stavki",
  "marketplace.empty.relevant": "Nisu pronađene relevantne stavke marketplacea za ovaj radni prostor.",
  "marketplace.badge.mcpServer": "MCP Server",
  "marketplace.badge.skills": "Uključuje vještine",
  "marketplace.card.by": "od {{author}}",
  "marketplace.install.method": "Metoda instalacije",
  "marketplace.install.parameters": "Parametri",
  "marketplace.install.optional": "(opciono)",
  "marketplace.scope.project": "projekat",
  "marketplace.scope.global": "globalno",
  "marketplace.remove.type.mcp": "MCP server",
  "marketplace.remove.type.plugin": "dodatak",
  "marketplace.remove.type.skill": "vještina",
  "marketplace.remove.type.agent": "agent",
  "marketplace.remove.failed": "Uklanjanje {{name}} nije uspjelo",
  "marketplace.install": "Instaliraj",
  "marketplace.filter.installed": "Instalirano",
  "marketplace.error.dismiss": "Odbaci",
  "marketplace.warning.busyOne": "Jedna sesija je pokrenuta i bit će prekinuta",
  "marketplace.warning.busyMany": "Nekoliko sesija je pokrenuto i bit će prekinuto",
  "marketplace.warning.installAnyway": "Instaliraj svejedno",
  "marketplace.warning.cancel": "Otkaži",
  "marketplace.contribute.prompt": "Nedostaje vještina, agent, MCP server ili dodatak?",
  "marketplace.contribute.cta": "Doprinesi na GitHub-u",
  "marketplace.migration.notice":
    "Modovi su zamijenjeni agentima. Ako ste prethodno instalirali marketplace modove, uklonite ih i ponovo instalirajte kao agente da biste prešli na novi format.",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "Implementiraj",
  "plan.followup.question": "Spreman za implementaciju?",
  "plan.followup.answer.newSession": "Pokreni novu sesiju",
  "plan.followup.answer.newSession.description": "Implementiraj u novoj sesiji s čistim kontekstom",
  "plan.followup.answer.continue": "Nastavi ovdje",
  "plan.followup.answer.continue.description": "Implementiraj plan u ovoj sesiji",
  "plan.followup.answer.keepRefining": "Nastavi dorađivati",
  "plan.followup.answer.keepRefining.description": "Nastavi planirati bez implementacije za sada",

  // Slow-repo snapshot prompt
  "snapshot.slowRepo.header": "Snapshot je spor",
  "snapshot.slowRepo.question":
    "Inicijalizacija sistema snapshotova traje dugo, vjerovatno zbog veličine repozitorija.\n\nŽelite li onemogućiti snapshotove za ovaj repozitorij?",
  "snapshot.slowRepo.answer.continue": "Nastavi sa snapshotovima",
  "snapshot.slowRepo.answer.continue.description":
    "Sačekaj da se snapshot završi. Naredni potezi su brzi kada se početni snapshot jednom napravi.",
  "snapshot.slowRepo.answer.disable": "Onemogući za ovaj projekat",
  "snapshot.slowRepo.answer.disable.description":
    "Isključi Aura snapshotove za ovaj projekat. Izgubićete poništi/vrati za izmjene koje napravi Aura, ali git i dalje prati sve.",

  // Edit-tool header and shell-tool section labels
  "ui.messagePart.openInDiffViewer": "Otvori u pregledniku razlika",
  "ui.messagePart.openInEditor": "Otvori u editoru",

  // Message feedback (thumbs up/down per assistant response)
  "ui.message.feedback.helpful": "Ovo je bilo korisno",
  "ui.message.feedback.notHelpful": "Ovo nije bilo korisno",
  "ui.message.feedback.clearRating": "Obriši ocjenu",
}
