export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "Para mais estatísticas de uso, utilize ",
  "provider.connect.auraGateway.byok.link": "BYOK via Aura's Gateway",
  "provider.connect.auraGateway.byok.suffix": ".",

  // Provider settings translations
  "settings.providers.group.recommended": "Recomendados",
  "settings.providers.note.aura": "Acesso a mais de 500 modelos de IA",
  "settings.providers.note.opencode": "Modelos selecionados, incluindo Claude, GPT, Gemini e mais",
  "settings.providers.note.anthropic": "Acesso direto aos modelos Claude, incluindo Pro e Max",
  "settings.providers.note.deepseek": "Modelos DeepSeek para tarefas de raciocínio e programação",
  "settings.providers.note.copilot": "Modelos Claude para assistência em programação",
  "settings.providers.note.openai": "Modelos GPT e Codex com chave de API ou login do ChatGPT",
  "settings.providers.note.google": "Modelos Gemini para respostas rápidas e estruturadas",
  "settings.providers.note.openrouter": "Acesse todos os modelos compatíveis em um só provedor",
  "settings.providers.note.vercel": "Acesso unificado a modelos de IA com roteamento inteligente",

  // Reasoning block label
  "ui.reasoning.label": "Raciocínio",

  // Marketplace
  "marketplace.card.installed": "Instalado",
  "marketplace.card.install": "Instalar",
  "marketplace.card.remove": "Remover",
  "marketplace.card.removeScope": "Remover ({{scope}})",
  "marketplace.card.showMore": "Mostrar mais",
  "marketplace.card.showLess": "Mostrar menos",
  "marketplace.install.title": "Instalar {{name}}",
  "marketplace.install.scope": "Escopo",
  "marketplace.install.scope.project": "Projeto",
  "marketplace.install.scope.global": "Global",
  "marketplace.install.scope.project.description":
    "Somente este projeto. Os arquivos instalados podem ser adicionados ao controle de versão e compartilhados com sua equipe.",
  "marketplace.install.scope.global.description":
    "Todos os projetos nesta máquina. Armazenado na sua configuração de usuário.",
  "marketplace.install.destination": "Destino da instalação",
  "marketplace.install.includedSkills": "Habilidades incluídas",
  "marketplace.install.about.mcp":
    "Um servidor MCP fornece ao Aura ferramentas adicionais para trabalhar com serviços externos ou programas locais.",
  "marketplace.install.about.agent": "Um agente adiciona uma função reutilizável com instruções e permissões próprias.",
  "marketplace.install.about.skill":
    "Uma habilidade adiciona instruções e recursos específicos para tarefas que o Aura pode carregar quando necessário.",
  "marketplace.install.mcp.warning":
    "Servidores MCP podem executar comandos locais ou se conectar a serviços externos. O Aura solicitará permissão antes de usar suas ferramentas, a menos que suas permissões permitam isso automaticamente.",
  "marketplace.install.project.warning":
    "Os arquivos do projeto podem ser adicionados ao controle de versão. Não armazene segredos aqui, a menos que a configuração faça referência a uma variável de ambiente.",
  "marketplace.install.learnMore": "Saiba como funcionam as instalações do Marketplace",
  "marketplace.install.learnMcp": "Saiba mais sobre MCP",
  "marketplace.install.about.plugin":
    "Um plugin adiciona ferramentas e integrações personalizadas ao Aura. Os plugins são executados com permissões totais.",
  "marketplace.install.plugin.warning":
    "Os plugins executam código com permissões totais. Eles podem ler e alterar seus arquivos, executar comandos e acessar suas credenciais e sua rede. Instale apenas plugins em que você confia.",
  "marketplace.intro":
    "Instale agentes, habilidades, ferramentas MCP e plugins reutilizáveis em um projeto ou em todos os projetos.",
  "marketplace.intro.learnMore": "Sobre o Marketplace",
  "marketplace.install.prerequisites": "Pré-requisitos",
  "marketplace.install.installing": "Instalando...",
  "marketplace.install.cancel": "Cancelar",
  "marketplace.install.success": "Instalado com sucesso!",
  "marketplace.install.failed": "Falha na instalação",
  "marketplace.install.done": "Concluído",
  "marketplace.install.close": "Fechar",
  "marketplace.install.mcp.signIn.message": "{{name}} está instalado, mas precisa de login antes que suas ferramentas possam ser usadas.",
  "marketplace.install.mcp.signIn.button": "Entrar",
  "marketplace.install.mcp.signIn.waiting": "Aguardando login pelo navegador…",
  "marketplace.install.mcp.signIn.cancel": "Cancelar",
  "marketplace.install.mcp.signIn.skip": "Mais tarde",
  "marketplace.install.mcp.signIn.success": "Login realizado em {{name}}.",
  "marketplace.install.mcp.signIn.failed": "Falha ao fazer login em {{name}}.",
  "marketplace.remove.title": "Remover {{name}}?",
  "marketplace.remove.confirm":
    "Tem certeza que deseja remover este {{type}}? Isso o removerá da sua configuração {{scope}}.",
  "marketplace.remove.cancel": "Cancelar",
  "marketplace.remove.mcp.skills":
    "Isso também remove as habilidades complementares pertencentes a esta instalação. As habilidades instaladas de forma independente são mantidas.",
  "marketplace.remove.confirm.button": "Remover",
  "marketplace.search": "Pesquisar...",
  "marketplace.filter.all": "Todos os Itens",
  "marketplace.filter.notInstalled": "Não Instalado",
  "marketplace.filter.relevant": "Relevantes para meu espaço de trabalho",
  "marketplace.empty": "Nenhum item encontrado",
  "marketplace.empty.relevant": "Nenhum item relevante do marketplace foi encontrado para este espaço de trabalho.",
  "marketplace.badge.mcpServer": "Servidor MCP",
  "marketplace.badge.skills": "Inclui habilidades",
  "marketplace.card.by": "por {{author}}",
  "marketplace.install.method": "Método de Instalação",
  "marketplace.install.parameters": "Parâmetros",
  "marketplace.install.optional": "(opcional)",
  "marketplace.scope.project": "projeto",
  "marketplace.scope.global": "global",
  "marketplace.remove.type.mcp": "servidor MCP",
  "marketplace.remove.type.plugin": "plugin",
  "marketplace.remove.type.skill": "habilidade",
  "marketplace.remove.type.agent": "agente",
  "marketplace.remove.failed": "Falha ao remover {{name}}",
  "marketplace.install": "Instalar",
  "marketplace.filter.installed": "Instalado",
  "marketplace.error.dismiss": "Dispensar",
  "marketplace.warning.busyOne": "Uma sessão está em execução e será interrompida",
  "marketplace.warning.busyMany": "Várias sessões estão em execução e serão interrompidas",
  "marketplace.warning.installAnyway": "Instalar mesmo assim",
  "marketplace.warning.cancel": "Cancelar",
  "marketplace.contribute.prompt": "Está faltando uma skill, agente, servidor MCP ou plugin?",
  "marketplace.contribute.cta": "Contribuir no GitHub",
  "marketplace.migration.notice":
    "Os modos foram substituídos por agentes. Se você instalou modos do marketplace anteriormente, remova-os e reinstale-os como agentes para migrar para o novo formato.",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "Implementar",
  "plan.followup.question": "Pronto para implementar?",
  "plan.followup.answer.newSession": "Iniciar nova sessão",
  "plan.followup.answer.newSession.description": "Implementar em uma nova sessão com contexto limpo",
  "plan.followup.answer.continue": "Continuar aqui",
  "plan.followup.answer.continue.description": "Implementar o plano nesta sessão",
  "plan.followup.answer.keepRefining": "Continuar refinando",
  "plan.followup.answer.keepRefining.description": "Continuar planejando sem implementar ainda",

  // Slow-repo snapshot prompt
  "snapshot.slowRepo.header": "Snapshot está lento",
  "snapshot.slowRepo.question":
    "Está demorando muito para inicializar o sistema de snapshots, provavelmente por causa do tamanho do repositório.\n\nDeseja desativar os snapshots para este repositório?",
  "snapshot.slowRepo.answer.continue": "Continuar com snapshots",
  "snapshot.slowRepo.answer.continue.description":
    "Aguarde a conclusão do snapshot. Os próximos turnos serão rápidos depois que o snapshot inicial for criado.",
  "snapshot.slowRepo.answer.disable": "Desativar para este projeto",
  "snapshot.slowRepo.answer.disable.description":
    "Desligue os snapshots do Aura para este projeto. Você perde desfazer/refazer das mudanças feitas pelo Aura, mas o git continua rastreando tudo.",

  // Edit-tool header and shell-tool section labels
  "ui.messagePart.openInDiffViewer": "Abrir no Visualizador de Diferenças",
  "ui.messagePart.openInEditor": "Abrir no Editor",

  // Message feedback (thumbs up/down per assistant response)
  "ui.message.feedback.helpful": "Isso foi útil",
  "ui.message.feedback.notHelpful": "Isso não foi útil",
  "ui.message.feedback.clearRating": "Limpar avaliação",
}
