export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "Für weitere Nutzungsstatistiken ",
  "provider.connect.auraGateway.byok.link": "BYOK via Aura's Gateway",
  "provider.connect.auraGateway.byok.suffix": " nutzen.",

  // Provider settings translations
  "settings.providers.group.recommended": "Empfohlen",
  "settings.providers.note.aura": "Zugriff auf 500+ KI-Modelle",
  "settings.providers.note.opencode": "Kuratierte Modelle, darunter Claude, GPT, Gemini und mehr",
  "settings.providers.note.anthropic": "Direkter Zugriff auf Claude-Modelle, einschließlich Pro und Max",
  "settings.providers.note.deepseek": "DeepSeek-Modelle für Denk- und Programmieraufgaben",
  "settings.providers.note.copilot": "Claude-Modelle für Programmierunterstützung",
  "settings.providers.note.openai": "GPT- und Codex-Modelle mit API-Schlüssel oder ChatGPT-Anmeldung",
  "settings.providers.note.google": "Gemini-Modelle für schnelle, strukturierte Antworten",
  "settings.providers.note.openrouter": "Zugriff auf alle unterstützten Modelle über einen Anbieter",
  "settings.providers.note.vercel": "Einheitlicher Zugriff auf KI-Modelle mit intelligentem Routing",

  // Reasoning block label
  "ui.reasoning.label": "Denken",

  // Marketplace
  "marketplace.card.installed": "Installiert",
  "marketplace.card.install": "Installieren",
  "marketplace.card.remove": "Entfernen",
  "marketplace.card.removeScope": "Entfernen ({{scope}})",
  "marketplace.card.showMore": "Mehr anzeigen",
  "marketplace.card.showLess": "Weniger anzeigen",
  "marketplace.install.title": "{{name}} installieren",
  "marketplace.install.scope": "Bereich",
  "marketplace.install.scope.project": "Projekt",
  "marketplace.install.scope.global": "Global",
  "marketplace.install.scope.project.description":
    "Nur dieses Projekt. Die installierten Dateien können versioniert und mit Ihrem Team geteilt werden.",
  "marketplace.install.scope.global.description":
    "Alle Projekte auf diesem Computer. Wird in Ihrer Benutzerkonfiguration gespeichert.",
  "marketplace.install.destination": "Installationsziel",
  "marketplace.install.includedSkills": "Enthaltene Skills",
  "marketplace.install.about.mcp":
    "Ein MCP-Server stellt Aura zusätzliche Werkzeuge für die Arbeit mit externen Diensten oder lokalen Programmen bereit.",
  "marketplace.install.about.agent":
    "Ein Agent fügt eine wiederverwendbare Rolle mit eigenen Anweisungen und Berechtigungen hinzu.",
  "marketplace.install.about.skill":
    "Ein Skill fügt aufgabenspezifische Anweisungen und Ressourcen hinzu, die Aura bei Bedarf laden kann.",
  "marketplace.install.mcp.warning":
    "MCP-Server können lokale Befehle ausführen oder eine Verbindung zu externen Diensten herstellen. Aura fragt vor der Verwendung ihrer Werkzeuge um Erlaubnis, sofern Ihre Berechtigungen dies nicht automatisch erlauben.",
  "marketplace.install.project.warning":
    "Projektdateien können in die Versionsverwaltung aufgenommen werden. Speichern Sie hier keine Geheimnisse, es sei denn, die Konfiguration verweist auf eine Umgebungsvariable.",
  "marketplace.install.learnMore": "Erfahren Sie, wie Installationen aus dem Marketplace funktionieren",
  "marketplace.install.learnMcp": "Mehr über MCP erfahren",
  "marketplace.install.about.plugin":
    "Ein Plugin fügt Aura benutzerdefinierte Werkzeuge und Integrationen hinzu. Plugins werden mit vollständigen Berechtigungen ausgeführt.",
  "marketplace.install.plugin.warning":
    "Plugins führen Code mit vollständigen Berechtigungen aus. Sie können Ihre Dateien lesen und ändern, Befehle ausführen und auf Ihre Zugangsdaten und Ihr Netzwerk zugreifen. Installieren Sie nur Plugins, denen Sie vertrauen.",
  "marketplace.intro":
    "Installieren Sie wiederverwendbare Agenten, Skills, MCP-Werkzeuge und Plugins für ein Projekt oder für alle Projekte.",
  "marketplace.intro.learnMore": "Über den Marketplace",
  "marketplace.install.prerequisites": "Voraussetzungen",
  "marketplace.install.installing": "Wird installiert...",
  "marketplace.install.cancel": "Abbrechen",
  "marketplace.install.success": "Erfolgreich installiert!",
  "marketplace.install.failed": "Installation fehlgeschlagen",
  "marketplace.install.done": "Fertig",
  "marketplace.install.close": "Schließen",
  "marketplace.install.mcp.signIn.message": "{{name}} ist installiert, benötigt aber eine Anmeldung, bevor die Tools verwendet werden können.",
  "marketplace.install.mcp.signIn.button": "Anmelden",
  "marketplace.install.mcp.signIn.waiting": "Warten auf Anmeldung im Browser…",
  "marketplace.install.mcp.signIn.cancel": "Abbrechen",
  "marketplace.install.mcp.signIn.skip": "Später",
  "marketplace.install.mcp.signIn.success": "Bei {{name}} angemeldet.",
  "marketplace.install.mcp.signIn.failed": "Anmeldung bei {{name}} fehlgeschlagen.",
  "marketplace.remove.title": "{{name}} entfernen?",
  "marketplace.remove.confirm":
    "Soll dieser Eintrag ({{type}}) wirklich entfernt werden? Er wird dadurch aus Ihrer {{scope}}-Konfiguration entfernt.",
  "marketplace.remove.cancel": "Abbrechen",
  "marketplace.remove.mcp.skills":
    "Dabei werden auch die zu dieser Installation gehörenden Begleit-Skills entfernt. Unabhängig installierte Skills bleiben erhalten.",
  "marketplace.remove.confirm.button": "Entfernen",
  "marketplace.search": "Suchen...",
  "marketplace.filter.all": "Alle Elemente",
  "marketplace.filter.notInstalled": "Nicht installiert",
  "marketplace.filter.relevant": "Relevant für meinen Arbeitsbereich",
  "marketplace.empty": "Keine Elemente gefunden",
  "marketplace.empty.relevant": "Keine relevanten Marketplace-Elemente für diesen Arbeitsbereich gefunden.",
  "marketplace.badge.mcpServer": "MCP-Server",
  "marketplace.badge.skills": "Enthält Skills",
  "marketplace.card.by": "von {{author}}",
  "marketplace.install.method": "Installationsmethode",
  "marketplace.install.parameters": "Parameter",
  "marketplace.install.optional": "(optional)",
  "marketplace.scope.project": "Projekt",
  "marketplace.scope.global": "Global",
  "marketplace.remove.type.mcp": "MCP-Server",
  "marketplace.remove.type.plugin": "Plugin",
  "marketplace.remove.type.skill": "Skill",
  "marketplace.remove.type.agent": "Agent",
  "marketplace.remove.failed": "Fehler beim Entfernen von {{name}}",
  "marketplace.install": "Installieren",
  "marketplace.filter.installed": "Installiert",
  "marketplace.error.dismiss": "Verwerfen",
  "marketplace.warning.busyOne": "Eine Sitzung läuft und wird unterbrochen",
  "marketplace.warning.busyMany": "Mehrere Sitzungen laufen und werden unterbrochen",
  "marketplace.warning.installAnyway": "Trotzdem installieren",
  "marketplace.warning.cancel": "Abbrechen",
  "marketplace.contribute.prompt": "Fehlt ein Skill, Agent, MCP-Server oder Plugin?",
  "marketplace.contribute.cta": "Auf GitHub beitragen",
  "marketplace.migration.notice":
    "Modi wurden durch Agenten ersetzt. Wenn Sie zuvor Marketplace-Modi installiert haben, entfernen Sie diese bitte und installieren Sie sie als Agenten neu, um zum neuen Format zu migrieren.",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "Umsetzen",
  "plan.followup.question": "Bereit zur Umsetzung?",
  "plan.followup.answer.newSession": "Neue Sitzung starten",
  "plan.followup.answer.newSession.description": "In einer neuen Sitzung mit leerem Kontext umsetzen",
  "plan.followup.answer.continue": "Hier fortfahren",
  "plan.followup.answer.continue.description": "Den Plan in dieser Sitzung umsetzen",
  "plan.followup.answer.keepRefining": "Weiter verfeinern",
  "plan.followup.answer.keepRefining.description": "Weiter planen, ohne jetzt zu implementieren",

  // Slow-repo snapshot prompt
  "snapshot.slowRepo.header": "Snapshot ist langsam",
  "snapshot.slowRepo.question":
    "Die Initialisierung des Snapshot-Systems dauert lange, wahrscheinlich aufgrund der Größe des Repositorys.\n\nMöchtest du Snapshots für dieses Repository deaktivieren?",
  "snapshot.slowRepo.answer.continue": "Snapshots beibehalten",
  "snapshot.slowRepo.answer.continue.description":
    "Auf den Abschluss des Snapshots warten. Nachfolgende Runden sind schnell, sobald der initiale Snapshot erstellt ist.",
  "snapshot.slowRepo.answer.disable": "Für dieses Projekt deaktivieren",
  "snapshot.slowRepo.answer.disable.description":
    "Aura-Snapshots für dieses Projekt ausschalten. Rückgängig/Wiederherstellen für Aura-Änderungen ist nicht mehr möglich, aber git verfolgt weiterhin alles.",

  // Edit-tool header and shell-tool section labels
  "ui.messagePart.openInDiffViewer": "Im Diff-Viewer öffnen",
  "ui.messagePart.openInEditor": "Im Editor öffnen",

  // Message feedback (thumbs up/down per assistant response)
  "ui.message.feedback.helpful": "Das war hilfreich",
  "ui.message.feedback.notHelpful": "Das war nicht hilfreich",
  "ui.message.feedback.clearRating": "Bewertung löschen",
}
