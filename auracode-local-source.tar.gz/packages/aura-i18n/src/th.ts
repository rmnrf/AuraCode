export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "สำหรับสถิติการใช้งานเพิ่มเติม โปรดใช้ ",
  "provider.connect.auraGateway.byok.link": "BYOK ผ่าน Aura's Gateway",
  "provider.connect.auraGateway.byok.suffix": "",

  // Provider settings translations
  "settings.providers.group.recommended": "แนะนำ",
  "settings.providers.note.aura": "เข้าถึงโมเดล AI มากกว่า 500 รายการ",
  "settings.providers.note.opencode": "โมเดลที่คัดสรร รวมถึง Claude, GPT, Gemini และอื่น ๆ",
  "settings.providers.note.anthropic": "เข้าถึงโมเดล Claude โดยตรง รวมถึง Pro และ Max",
  "settings.providers.note.deepseek": "โมเดล DeepSeek สำหรับงานใช้เหตุผลและเขียนโค้ด",
  "settings.providers.note.copilot": "โมเดล Claude สำหรับช่วยเขียนโค้ด",
  "settings.providers.note.openai": "โมเดล GPT และ Codex พร้อมคีย์ API หรือการเข้าสู่ระบบ ChatGPT",
  "settings.providers.note.google": "โมเดล Gemini สำหรับคำตอบที่รวดเร็วและเป็นโครงสร้าง",
  "settings.providers.note.openrouter": "เข้าถึงโมเดลที่รองรับทั้งหมดจากผู้ให้บริการเดียว",
  "settings.providers.note.vercel": "เข้าถึงโมเดล AI แบบรวมศูนย์พร้อมการกำหนดเส้นทางอัจฉริยะ",

  // Reasoning block label
  "ui.reasoning.label": "การให้เหตุผล",

  // Marketplace
  "marketplace.card.installed": "ติดตั้งแล้ว",
  "marketplace.card.install": "ติดตั้ง",
  "marketplace.card.remove": "ลบ",
  "marketplace.card.removeScope": "ลบ ({{scope}})",
  "marketplace.card.showMore": "แสดงเพิ่มเติม",
  "marketplace.card.showLess": "แสดงน้อยลง",
  "marketplace.install.title": "ติดตั้ง {{name}}",
  "marketplace.install.scope": "ขอบเขต",
  "marketplace.install.scope.project": "โปรเจกต์",
  "marketplace.install.scope.global": "โกลบอล",
  "marketplace.install.scope.project.description":
    "เฉพาะโปรเจกต์นี้ ไฟล์ที่ติดตั้งสามารถเพิ่มลงในระบบควบคุมเวอร์ชันและแชร์กับทีมของคุณได้",
  "marketplace.install.scope.global.description": "ทุกโปรเจกต์ในเครื่องนี้ จัดเก็บไว้ในการกำหนดค่าผู้ใช้ของคุณ",
  "marketplace.install.destination": "ปลายทางการติดตั้ง",
  "marketplace.install.includedSkills": "ทักษะที่รวมมาด้วย",
  "marketplace.install.about.mcp":
    "เซิร์ฟเวอร์ MCP เพิ่มเครื่องมือให้ Aura สำหรับทำงานกับบริการภายนอกหรือโปรแกรมในเครื่อง",
  "marketplace.install.about.agent": "เอเจนต์เพิ่มบทบาทที่นำกลับมาใช้ใหม่ได้พร้อมคำสั่งและสิทธิ์ของตนเอง",
  "marketplace.install.about.skill": "ทักษะเพิ่มคำสั่งและทรัพยากรเฉพาะงานที่ Aura สามารถโหลดได้เมื่อจำเป็น",
  "marketplace.install.mcp.warning":
    "เซิร์ฟเวอร์ MCP สามารถเรียกใช้คำสั่งในเครื่องหรือเชื่อมต่อกับบริการภายนอกได้ Aura จะขออนุญาตก่อนใช้เครื่องมือ เว้นแต่สิทธิ์ของคุณจะอนุญาตโดยอัตโนมัติ",
  "marketplace.install.project.warning":
    "ไฟล์โปรเจกต์อาจถูกเพิ่มลงในระบบควบคุมเวอร์ชัน อย่าเก็บข้อมูลลับไว้ที่นี่ เว้นแต่การกำหนดค่าจะอ้างอิงตัวแปรสภาพแวดล้อม",
  "marketplace.install.learnMore": "เรียนรู้วิธีการติดตั้งจาก Marketplace",
  "marketplace.install.learnMcp": "เรียนรู้เพิ่มเติมเกี่ยวกับ MCP",
  "marketplace.install.about.plugin":
    "ปลั๊กอินเพิ่มเครื่องมือและการเชื่อมต่อแบบกำหนดเองให้กับ Aura ปลั๊กอินทำงานโดยมีสิทธิ์เต็มรูปแบบ",
  "marketplace.install.plugin.warning":
    "ปลั๊กอินเรียกใช้โค้ดโดยมีสิทธิ์เต็มรูปแบบ สามารถอ่านและแก้ไขไฟล์ของคุณ เรียกใช้คำสั่ง และเข้าถึงข้อมูลรับรองและเครือข่ายของคุณได้ ติดตั้งเฉพาะปลั๊กอินที่คุณเชื่อถือเท่านั้น",
  "marketplace.intro":
    "ติดตั้งเอเจนต์ ทักษะ เครื่องมือ MCP และปลั๊กอินที่นำกลับมาใช้ใหม่ได้สำหรับหนึ่งโปรเจกต์หรือทุกโปรเจกต์",
  "marketplace.intro.learnMore": "เกี่ยวกับ Marketplace",
  "marketplace.install.prerequisites": "ข้อกำหนดเบื้องต้น",
  "marketplace.install.installing": "กำลังติดตั้ง...",
  "marketplace.install.cancel": "ยกเลิก",
  "marketplace.install.success": "ติดตั้งสำเร็จแล้ว!",
  "marketplace.install.failed": "การติดตั้งล้มเหลว",
  "marketplace.install.done": "เสร็จสิ้น",
  "marketplace.install.close": "ปิด",
  "marketplace.install.mcp.signIn.message": "{{name}} ติดตั้งแล้ว แต่ต้องเข้าสู่ระบบก่อนจึงจะใช้งานเครื่องมือได้",
  "marketplace.install.mcp.signIn.button": "เข้าสู่ระบบ",
  "marketplace.install.mcp.signIn.waiting": "กำลังรอการเข้าสู่ระบบผ่านเบราว์เซอร์…",
  "marketplace.install.mcp.signIn.cancel": "ยกเลิก",
  "marketplace.install.mcp.signIn.skip": "ไว้ทีหลัง",
  "marketplace.install.mcp.signIn.success": "เข้าสู่ระบบ {{name}} แล้ว",
  "marketplace.install.mcp.signIn.failed": "เข้าสู่ระบบ {{name}} ไม่สำเร็จ",
  "marketplace.remove.title": "ลบ {{name}} หรือไม่?",
  "marketplace.remove.confirm":
    "คุณแน่ใจหรือไม่ว่าต้องการลบ {{type}} นี้? สิ่งนี้จะลบออกจากการกำหนดค่า {{scope}} ของคุณ",
  "marketplace.remove.cancel": "ยกเลิก",
  "marketplace.remove.mcp.skills":
    "การดำเนินการนี้จะลบทักษะเสริมที่เป็นของการติดตั้งนี้ด้วย ทักษะที่ติดตั้งแยกต่างหากจะยังคงอยู่",
  "marketplace.remove.confirm.button": "ลบ",
  "marketplace.search": "ค้นหา...",
  "marketplace.filter.all": "รายการทั้งหมด",
  "marketplace.filter.notInstalled": "ยังไม่ได้ติดตั้ง",
  "marketplace.filter.relevant": "เกี่ยวข้องกับพื้นที่ทำงานของฉัน",
  "marketplace.empty": "ไม่พบรายการ",
  "marketplace.empty.relevant": "ไม่พบรายการในมาร์เก็ตเพลสที่เกี่ยวข้องกับพื้นที่ทำงานนี้",
  "marketplace.badge.mcpServer": "เซิร์ฟเวอร์ MCP",
  "marketplace.badge.skills": "มีทักษะรวมมาด้วย",
  "marketplace.card.by": "โดย {{author}}",
  "marketplace.install.method": "วิธีการติดตั้ง",
  "marketplace.install.parameters": "พารามิเตอร์",
  "marketplace.install.optional": "(ไม่บังคับ)",
  "marketplace.scope.project": "โปรเจ็กต์",
  "marketplace.scope.global": "โกลบอล",
  "marketplace.remove.type.mcp": "เซิร์ฟเวอร์ MCP",
  "marketplace.remove.type.plugin": "ปลั๊กอิน",
  "marketplace.remove.type.skill": "ทักษะ",
  "marketplace.remove.type.agent": "เอเจนต์",
  "marketplace.remove.failed": "ไม่สามารถลบ {{name}} ได้",
  "marketplace.install": "ติดตั้ง",
  "marketplace.filter.installed": "ติดตั้งแล้ว",
  "marketplace.error.dismiss": "ปิด",
  "marketplace.warning.busyOne": "มีเซสชันหนึ่งกำลังทำงานและจะถูกขัดจังหวะ",
  "marketplace.warning.busyMany": "มีหลายเซสชันกำลังทำงานและจะถูกขัดจังหวะ",
  "marketplace.warning.installAnyway": "ติดตั้งต่อไป",
  "marketplace.warning.cancel": "ยกเลิก",
  "marketplace.contribute.prompt": "ขาดสกิล เอเจนต์ เซิร์ฟเวอร์ MCP หรือปลั๊กอิน?",
  "marketplace.contribute.cta": "ร่วมสมทบบน GitHub",
  "marketplace.migration.notice":
    "โหมดถูกแทนที่ด้วยเอเจนต์แล้ว หากคุณเคยติดตั้งโหมดจาก marketplace กรุณาลบและติดตั้งใหม่เป็นเอเจนต์เพื่อย้ายไปยังรูปแบบใหม่",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "ดำเนินการ",
  "plan.followup.question": "พร้อมดำเนินการหรือยัง?",
  "plan.followup.answer.newSession": "เริ่มเซสชันใหม่",
  "plan.followup.answer.newSession.description": "ดำเนินการในเซสชันใหม่ที่มีบริบทว่างเปล่า",
  "plan.followup.answer.continue": "ดำเนินการต่อที่นี่",
  "plan.followup.answer.continue.description": "ดำเนินการตามแผนในเซสชันนี้",
  "plan.followup.answer.keepRefining": "ปรับแผนต่อ",
  "plan.followup.answer.keepRefining.description": "วางแผนต่อโดยยังไม่ดำเนินการ",

  // Slow-repo snapshot prompt
  "snapshot.slowRepo.header": "สแน็ปช็อตช้า",
  "snapshot.slowRepo.question":
    "การเริ่มต้นระบบสแน็ปช็อตใช้เวลานาน น่าจะเป็นเพราะขนาดของที่เก็บข้อมูล\n\nต้องการปิดสแน็ปช็อตสำหรับที่เก็บข้อมูลนี้หรือไม่?",
  "snapshot.slowRepo.answer.continue": "ใช้สแน็ปช็อตต่อ",
  "snapshot.slowRepo.answer.continue.description":
    "รอจนกว่าสแน็ปช็อตจะเสร็จ เทิร์นถัดไปจะเร็วขึ้นเมื่อสร้างสแน็ปช็อตแรกเสร็จแล้ว",
  "snapshot.slowRepo.answer.disable": "ปิดใช้งานสำหรับโปรเจกต์นี้",
  "snapshot.slowRepo.answer.disable.description":
    "ปิดสแน็ปช็อตของ Aura สำหรับโปรเจกต์นี้ คุณจะสูญเสียการยกเลิก/ทำซ้ำสำหรับการเปลี่ยนแปลงของ Aura แต่ git ยังคงติดตามทุกอย่าง",

  // Edit-tool header and shell-tool section labels
  "ui.messagePart.openInDiffViewer": "เปิดในตัวดูความแตกต่าง",
  "ui.messagePart.openInEditor": "เปิดในตัวแก้ไข",

  // Message feedback (thumbs up/down per assistant response)
  "ui.message.feedback.helpful": "สิ่งนี้มีประโยชน์",
  "ui.message.feedback.notHelpful": "สิ่งนี้ไม่มีประโยชน์",
  "ui.message.feedback.clearRating": "ล้างการให้คะแนน",
}
