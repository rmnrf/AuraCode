// Aura-specific translations and overrides
// Keys here will override any matching keys from upstream translations
export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "Per ulteriori statistiche sull'utilizzo, utilizza ",
  "provider.connect.auraGateway.byok.link": "BYOK tramite Aura's Gateway",
  "provider.connect.auraGateway.byok.suffix": ".",

  // Provider settings translations
  "settings.providers.group.recommended": "Consigliati",
  "settings.providers.note.aura": "Accesso a oltre 500 modelli AI",
  "settings.providers.note.opencode": "Modelli selezionati, inclusi Claude, GPT, Gemini e altri",
  "settings.providers.note.anthropic": "Accesso diretto ai modelli Claude, inclusi Pro e Max",
  "settings.providers.note.deepseek": "Modelli DeepSeek per attività di ragionamento e programmazione",
  "settings.providers.note.copilot": "Modelli Claude per assistenza alla programmazione",
  "settings.providers.note.openai": "Modelli GPT e Codex con chiave API o accesso ChatGPT",
  "settings.providers.note.google": "Modelli Gemini per risposte rapide e strutturate",
  "settings.providers.note.openrouter": "Accesso a tutti i modelli supportati da un unico provider",
  "settings.providers.note.vercel": "Accesso unificato ai modelli IA con routing intelligente",

  // Reasoning block label
  "ui.reasoning.label": "Ragionamento",

  // Marketplace
  "marketplace.card.installed": "Installato",
  "marketplace.card.install": "Installa",
  "marketplace.card.remove": "Rimuovi",
  "marketplace.card.removeScope": "Rimuovi ({{scope}})",
  "marketplace.card.showMore": "Mostra altro",
  "marketplace.card.showLess": "Mostra meno",
  "marketplace.install.title": "Installa {{name}}",
  "marketplace.install.scope": "Ambito",
  "marketplace.install.scope.project": "Progetto",
  "marketplace.install.scope.global": "Globale",
  "marketplace.install.scope.project.description":
    "Solo questo progetto. I file installati possono essere aggiunti al controllo versione e condivisi con il team.",
  "marketplace.install.scope.global.description":
    "Tutti i progetti su questo computer. Viene salvato nella configurazione utente.",
  "marketplace.install.destination": "Destinazione dell'installazione",
  "marketplace.install.includedSkills": "Skill incluse",
  "marketplace.install.about.mcp":
    "Un server MCP fornisce a Aura strumenti aggiuntivi per interagire con servizi esterni o programmi locali.",
  "marketplace.install.about.agent":
    "Un agente aggiunge un ruolo riutilizzabile con istruzioni e autorizzazioni proprie.",
  "marketplace.install.about.skill":
    "Una skill aggiunge istruzioni e risorse specifiche per un'attività che Aura può caricare quando necessario.",
  "marketplace.install.mcp.warning":
    "I server MCP possono eseguire comandi locali o connettersi a servizi esterni. Aura chiederà l'autorizzazione prima di usare i loro strumenti, a meno che le tue autorizzazioni non lo consentano automaticamente.",
  "marketplace.install.project.warning":
    "I file del progetto possono essere aggiunti al controllo versione. Non salvare segreti qui, a meno che la configurazione non faccia riferimento a una variabile di ambiente.",
  "marketplace.install.learnMore": "Scopri come funzionano le installazioni dal Marketplace",
  "marketplace.install.learnMcp": "Scopri di più su MCP",
  "marketplace.install.about.plugin":
    "Un plugin aggiunge strumenti e integrazioni personalizzati a Aura. I plugin vengono eseguiti con tutte le autorizzazioni.",
  "marketplace.install.plugin.warning":
    "I plugin eseguono codice con tutte le autorizzazioni. Possono leggere e modificare i tuoi file, eseguire comandi e accedere alle tue credenziali e alla tua rete. Installa solo plugin di cui ti fidi.",
  "marketplace.intro": "Installa agenti, skill, strumenti MCP e plugin riutilizzabili per uno o tutti i progetti.",
  "marketplace.intro.learnMore": "Informazioni sul Marketplace",
  "marketplace.install.prerequisites": "Prerequisiti",
  "marketplace.install.installing": "Installazione...",
  "marketplace.install.cancel": "Annulla",
  "marketplace.install.success": "Installato correttamente!",
  "marketplace.install.failed": "Installazione non riuscita",
  "marketplace.install.done": "Fatto",
  "marketplace.install.close": "Chiudi",
  "marketplace.install.mcp.signIn.message": "{{name}} è installato, ma richiede l'accesso prima che i suoi strumenti possano essere usati.",
  "marketplace.install.mcp.signIn.button": "Accedi",
  "marketplace.install.mcp.signIn.waiting": "In attesa dell'accesso tramite browser…",
  "marketplace.install.mcp.signIn.cancel": "Annulla",
  "marketplace.install.mcp.signIn.skip": "Più tardi",
  "marketplace.install.mcp.signIn.success": "Accesso effettuato a {{name}}.",
  "marketplace.install.mcp.signIn.failed": "Accesso a {{name}} non riuscito.",
  "marketplace.remove.title": "Rimuovere {{name}}?",
  "marketplace.remove.confirm": "Vuoi davvero rimuovere questo {{type}}? Verrà rimosso dalla configurazione {{scope}}.",
  "marketplace.remove.cancel": "Annulla",
  "marketplace.remove.mcp.skills":
    "Questa operazione rimuove anche le skill complementari appartenenti a questa installazione. Le skill installate in modo indipendente vengono conservate.",
  "marketplace.remove.confirm.button": "Rimuovi",
  "marketplace.search": "Cerca...",
  "marketplace.filter.all": "Tutti gli elementi",
  "marketplace.filter.notInstalled": "Non installati",
  "marketplace.filter.relevant": "Rilevanti per il mio spazio di lavoro",
  "marketplace.empty": "Nessun elemento trovato",
  "marketplace.empty.relevant": "Nessun elemento rilevante del marketplace trovato per questo spazio di lavoro.",
  "marketplace.badge.mcpServer": "Server MCP",
  "marketplace.badge.skills": "Include skill",
  "marketplace.card.by": "di {{author}}",
  "marketplace.install.method": "Metodo di installazione",
  "marketplace.install.parameters": "Parametri",
  "marketplace.install.optional": "(opzionale)",
  "marketplace.scope.project": "progetto",
  "marketplace.scope.global": "globale",
  "marketplace.remove.type.mcp": "server MCP",
  "marketplace.remove.type.plugin": "plugin",
  "marketplace.remove.type.skill": "skill",
  "marketplace.remove.type.agent": "agente",
  "marketplace.remove.failed": "Rimozione di {{name}} non riuscita",
  "marketplace.install": "Installa",
  "marketplace.filter.installed": "Installati",
  "marketplace.error.dismiss": "Ignora",
  "marketplace.warning.busyOne": "Una sessione è attiva e verrà interrotta",
  "marketplace.warning.busyMany": "Più sessioni sono attive e verranno interrotte",
  "marketplace.warning.installAnyway": "Installa comunque",
  "marketplace.warning.cancel": "Annulla",
  "marketplace.contribute.prompt": "Manca una skill, un agente, un server MCP o un plugin?",
  "marketplace.contribute.cta": "Contribuisci su GitHub",
  "marketplace.migration.notice":
    "Le Modalità sono state sostituite dagli agenti. Se in precedenza hai installato Modalità dal marketplace, rimuovile e reinstallale come agenti per migrare al nuovo formato.",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "Implementa",
  "plan.followup.question": "Pronto per implementare?",
  "plan.followup.answer.newSession": "Avvia una nuova sessione",
  "plan.followup.answer.newSession.description": "Implementa in una nuova sessione con contesto vuoto",
  "plan.followup.answer.continue": "Continua qui",
  "plan.followup.answer.continue.description": "Implementa il piano in questa sessione",
  "plan.followup.answer.keepRefining": "Continua a rifinire",
  "plan.followup.answer.keepRefining.description": "Continua a pianificare senza implementare per ora",

  "snapshot.slowRepo.header": "Snapshot lento",
  "snapshot.slowRepo.question":
    "L'inizializzazione del sistema snapshot sta richiedendo molto tempo, probabilmente a causa delle dimensioni del repository.\n\nVuoi disabilitare gli snapshot per questo repository?",
  "snapshot.slowRepo.answer.continue": "Continua con gli snapshot",
  "snapshot.slowRepo.answer.continue.description":
    "Continua ad attendere il completamento dello snapshot. Le iterazioni successive saranno rapide dopo la creazione dello snapshot iniziale.",
  "snapshot.slowRepo.answer.disable": "Disabilita per questo progetto",
  "snapshot.slowRepo.answer.disable.description":
    "Disattiva gli snapshot di Aura per questo progetto. Perderai annulla/ripeti sulle modifiche ai file fatte da Aura, ma git continuerà a tracciare tutto.",

  "ui.messagePart.openInDiffViewer": "Apri nel visualizzatore diff",
  "ui.messagePart.openInEditor": "Apri nell'editor",

  "ui.message.feedback.helpful": "È stato utile",
  "ui.message.feedback.notHelpful": "Non è stato utile",
  "ui.message.feedback.clearRating": "Cancella valutazione",
}
