export const dict = {
  // Aura Gateway provider translations
  "provider.connect.auraGateway.byok.prefix": "Daha fazla kullanım istatistiği için ",
  "provider.connect.auraGateway.byok.link": "Aura's Gateway üzerinden BYOK",
  "provider.connect.auraGateway.byok.suffix": " kullanın.",

  // Provider settings translations
  "settings.providers.group.recommended": "Önerilen",
  "settings.providers.note.aura": "500+ AI modeline erişim",
  "settings.providers.note.opencode": "Claude, GPT, Gemini ve daha fazlasını içeren seçilmiş modeller",
  "settings.providers.note.anthropic": "Pro ve Max dahil Claude modellerine doğrudan erişim",
  "settings.providers.note.deepseek": "Akıl yürütme ve kodlama görevleri için DeepSeek modelleri",
  "settings.providers.note.copilot": "Kodlama yardımı için Claude modelleri",
  "settings.providers.note.openai": "API anahtarı veya ChatGPT girişiyle GPT ve Codex modelleri",
  "settings.providers.note.google": "Hızlı, yapılandırılmış yanıtlar için Gemini modelleri",
  "settings.providers.note.openrouter": "Desteklenen tüm modellere tek sağlayıcıdan erişim",
  "settings.providers.note.vercel": "Akıllı yönlendirme ile AI modellerine birleşik erişim",

  // Reasoning block label
  "ui.reasoning.label": "Akıl Yürütme",

  // Marketplace
  "marketplace.card.installed": "Yüklendi",
  "marketplace.card.install": "Yükle",
  "marketplace.card.remove": "Kaldır",
  "marketplace.card.removeScope": "Kaldır ({{scope}})",
  "marketplace.card.showMore": "Daha fazla göster",
  "marketplace.card.showLess": "Daha az göster",
  "marketplace.install.title": "{{name}} yükle",
  "marketplace.install.scope": "Kapsam",
  "marketplace.install.scope.project": "Proje",
  "marketplace.install.scope.global": "Genel",
  "marketplace.install.scope.project.description":
    "Yalnızca bu proje. Yüklenen dosyalar sürüm kontrolüne eklenebilir ve ekibinizle paylaşılabilir.",
  "marketplace.install.scope.global.description": "Bu makinedeki tüm projeler. Kullanıcı yapılandırmanızda saklanır.",
  "marketplace.install.destination": "Yükleme hedefi",
  "marketplace.install.includedSkills": "Dahil edilen yetenekler",
  "marketplace.install.about.mcp":
    "Bir MCP sunucusu, harici hizmetler veya yerel programlarla çalışmak için Aura'ya ek araçlar sağlar.",
  "marketplace.install.about.agent":
    "Bir ajan, kendi talimatları ve izinleri olan yeniden kullanılabilir bir rol ekler.",
  "marketplace.install.about.skill":
    "Bir yetenek, Aura'nun gerektiğinde yükleyebileceği göreve özel talimatlar ve kaynaklar ekler.",
  "marketplace.install.mcp.warning":
    "MCP sunucuları yerel komutları çalıştırabilir veya harici hizmetlere bağlanabilir. İzinleriniz otomatik olarak izin vermediği sürece Aura, araçlarını kullanmadan önce izin ister.",
  "marketplace.install.project.warning":
    "Proje dosyaları sürüm kontrolüne eklenebilir. Yapılandırma bir ortam değişkenine başvurmuyorsa gizli bilgileri burada saklamayın.",
  "marketplace.install.learnMore": "Marketplace yüklemelerinin nasıl çalıştığını öğrenin",
  "marketplace.install.learnMcp": "MCP hakkında daha fazla bilgi edinin",
  "marketplace.install.about.plugin":
    "Bir eklenti, Aura'ya özel araçlar ve entegrasyonlar ekler. Eklentiler tam izinlerle çalışır.",
  "marketplace.install.plugin.warning":
    "Eklentiler tam izinlerle kod çalıştırır. Dosyalarınızı okuyup değiştirebilir, komut çalıştırabilir ve kimlik bilgilerinize ve ağınıza erişebilirler. Yalnızca güvendiğiniz eklentileri yükleyin.",
  "marketplace.intro":
    "Yeniden kullanılabilir ajanları, yetenekleri, MCP araçlarını ve eklentileri bir proje veya tüm projeler için yükleyin.",
  "marketplace.intro.learnMore": "Marketplace hakkında",
  "marketplace.install.prerequisites": "Ön koşullar",
  "marketplace.install.installing": "Yükleniyor...",
  "marketplace.install.cancel": "İptal",
  "marketplace.install.success": "Başarıyla yüklendi!",
  "marketplace.install.failed": "Yükleme başarısız oldu",
  "marketplace.install.done": "Bitti",
  "marketplace.install.close": "Kapat",
  "marketplace.install.mcp.signIn.message": "{{name}} yüklendi, ancak araçlarının kullanılabilmesi için önce oturum açılması gerekiyor.",
  "marketplace.install.mcp.signIn.button": "Giriş Yap",
  "marketplace.install.mcp.signIn.waiting": "Tarayıcıda oturum açma bekleniyor…",
  "marketplace.install.mcp.signIn.cancel": "İptal",
  "marketplace.install.mcp.signIn.skip": "Daha sonra",
  "marketplace.install.mcp.signIn.success": "{{name}} oturumu açıldı.",
  "marketplace.install.mcp.signIn.failed": "{{name}} oturumu açılamadı.",
  "marketplace.remove.title": "{{name}} kaldırılsın mı?",
  "marketplace.remove.confirm":
    "Bu {{type}} öğesini kaldırmak istediğinizden emin misiniz? Bu, {{scope}} yapılandırmanızdan kaldırılacaktır.",
  "marketplace.remove.cancel": "İptal",
  "marketplace.remove.mcp.skills":
    "Bu işlem, bu yüklemeye ait tamamlayıcı yetenekleri de kaldırır. Bağımsız olarak yüklenen yetenekler korunur.",
  "marketplace.remove.confirm.button": "Kaldır",
  "marketplace.search": "Ara...",
  "marketplace.filter.all": "Tüm Öğeler",
  "marketplace.filter.notInstalled": "Yüklü Değil",
  "marketplace.filter.relevant": "Çalışma alanımla ilgili",
  "marketplace.empty": "Öğe bulunamadı",
  "marketplace.empty.relevant": "Bu çalışma alanıyla ilgili marketplace öğesi bulunamadı.",
  "marketplace.badge.mcpServer": "MCP Sunucusu",
  "marketplace.badge.skills": "Yetenekler içerir",
  "marketplace.card.by": "{{author}} tarafından",
  "marketplace.install.method": "Yükleme Yöntemi",
  "marketplace.install.parameters": "Parametreler",
  "marketplace.install.optional": "(isteğe bağlı)",
  "marketplace.scope.project": "proje",
  "marketplace.scope.global": "genel",
  "marketplace.remove.type.mcp": "MCP sunucusu",
  "marketplace.remove.type.plugin": "eklenti",
  "marketplace.remove.type.skill": "yetenek",
  "marketplace.remove.type.agent": "ajan",
  "marketplace.remove.failed": "{{name}} kaldırılamadı",
  "marketplace.install": "Yükle",
  "marketplace.filter.installed": "Yüklendi",
  "marketplace.error.dismiss": "Kapat",
  "marketplace.warning.busyOne": "Bir oturum çalışıyor ve kesintiye uğrayacak",
  "marketplace.warning.busyMany": "Birden fazla oturum çalışıyor ve kesintiye uğrayacak",
  "marketplace.warning.installAnyway": "Yine de yükle",
  "marketplace.warning.cancel": "İptal",
  "marketplace.contribute.prompt": "Bir yetenek, ajan, MCP sunucusu veya eklenti mi eksik?",
  "marketplace.contribute.cta": "GitHub'da katkıda bulun",
  "marketplace.migration.notice":
    "Modlar agentlarla değiştirildi. Daha önce marketplace modları yüklediyseniz, yeni formata geçiş yapmak için bunları kaldırın ve agent olarak yeniden yükleyin.",

  // Plan follow-up question shown after plan_exit
  "plan.followup.header": "Uygula",
  "plan.followup.question": "Uygulamaya hazır mısın?",
  "plan.followup.answer.newSession": "Yeni oturum başlat",
  "plan.followup.answer.newSession.description": "Temiz bir bağlamla yeni bir oturumda uygula",
  "plan.followup.answer.continue": "Burada devam et",
  "plan.followup.answer.continue.description": "Planı bu oturumda uygula",
  "plan.followup.answer.keepRefining": "İyileştirmeye devam et",
  "plan.followup.answer.keepRefining.description": "Henüz uygulamadan planlamaya devam et",

  // Slow-repo snapshot prompt
  "snapshot.slowRepo.header": "Anlık görüntü yavaş",
  "snapshot.slowRepo.question":
    "Anlık görüntü sisteminin başlatılması uzun sürüyor, muhtemelen deponun boyutu nedeniyle.\n\nBu depo için anlık görüntüleri devre dışı bırakmak istiyor musunuz?",
  "snapshot.slowRepo.answer.continue": "Anlık görüntülerle devam et",
  "snapshot.slowRepo.answer.continue.description":
    "Anlık görüntü tamamlanana kadar bekleyin. İlk anlık görüntü oluşturulduktan sonra sonraki turlar hızlıdır.",
  "snapshot.slowRepo.answer.disable": "Bu proje için devre dışı bırak",
  "snapshot.slowRepo.answer.disable.description":
    "Bu proje için Aura anlık görüntülerini kapat. Aura değişiklikleri için geri alma/yeniden yapmayı kaybedersiniz, ancak git her şeyi izlemeye devam eder.",

  // Edit-tool header and shell-tool section labels
  "ui.messagePart.openInDiffViewer": "Fark Görüntüleyicide Aç",
  "ui.messagePart.openInEditor": "Düzenleyicide Aç",

  // Message feedback (thumbs up/down per assistant response)
  "ui.message.feedback.helpful": "Bu yardımcı oldu",
  "ui.message.feedback.notHelpful": "Bu yardımcı olmadı",
  "ui.message.feedback.clearRating": "Değerlendirmeyi temizle",
}
