import { execFile } from "child_process"
import type { DeviceAuthPollResponse } from "../types.js"
import { poll } from "./polling.js"
import { initiateDeviceAuth, pollDeviceAuth } from "./device.js"
import { getAuraProfile, getAuraDefaultModel, defaultOrganizationId } from "../api/profile.js"
import { POLL_INTERVAL_MS } from "../api/constants.js"
import type { AuthOuathResult } from "@auracode/plugin"

/**
 * TUI-compatible device authorization flow
 *
 * This version is designed to work with the TUI dialog system.
 * It completes the OAuth flow and returns credentials.
 * Organization selection is handled separately by the TUI layer using the profile data.
 */
export async function authenticateWithDeviceAuthTUI(inputs?: Record<string, string>): Promise<AuthOuathResult> {
  // Step 1: Initiate device auth
  const authData = await initiateDeviceAuth()
  const { code, verificationUrl, expiresIn } = authData

  // Step 2: Open browser (windowsHide: true prevents cmd.exe flash on Windows)
  const [cmd, ...args] =
    process.platform === "darwin"
      ? ["open", verificationUrl]
      : process.platform === "win32"
        ? ["cmd", "/c", "start", "", verificationUrl]
        : ["xdg-open", verificationUrl]
  execFile(cmd, args, { windowsHide: true })

  // Step 3: Return instructions and callback for TUI to handle
  return {
    url: verificationUrl,
    instructions: `Open ${verificationUrl} and enter code: ${code}`,
    method: "auto",
    async callback() {
      // Poll for authorization
      const maxAttempts = Math.ceil((expiresIn * 1000) / POLL_INTERVAL_MS)

      const result = await poll<DeviceAuthPollResponse>({
        interval: POLL_INTERVAL_MS,
        maxAttempts,
        pollFn: async () => {
          const pollResult = await pollDeviceAuth(code)

          if (pollResult.status === "approved") {
            return {
              continue: false,
              data: pollResult,
            }
          }

          if (pollResult.status === "denied") {
            return {
              continue: false,
              error: new Error("Authorization denied by user"),
            }
          }

          if (pollResult.status === "expired") {
            return {
              continue: false,
              error: new Error("Authorization code expired"),
            }
          }

          return {
            continue: true,
          }
        },
      })

      if (!result.token || !result.userEmail) {
        return { type: "failed" }
      }

      const token = result.token

      // Apply the cloud-selected organization as the login-time default.
      // After this, the stored accountId is authoritative; the user can switch
      // freely and profile fetches never re-derive it from the cloud.
      const profile = await getAuraProfile(token).catch(() => undefined)
      const organizationId = profile ? defaultOrganizationId(profile) : undefined

      // Fetch default model
      await getAuraDefaultModel(token, organizationId)

      // Return success with OAuth credentials
      return {
        type: "success",
        provider: "aura",
        refresh: token,
        access: token,
        expires: Date.now() + 365 * 24 * 60 * 60 * 1000, // 1 year
        ...(organizationId && { accountId: organizationId }),
      }
    },
  }
}
