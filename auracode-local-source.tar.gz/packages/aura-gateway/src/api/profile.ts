import { select } from "@clack/prompts"
import type { AuracodeProfile, Organization, AuracodeBalance } from "../types.js"
import { AURA_API_BASE, DEFAULT_MODEL, DEFAULT_FREE_MODEL } from "./constants.js"

/**
 * Fetch user profile from Aura API
 */
export async function fetchProfile(token: string): Promise<AuracodeProfile> {
  const response = await fetch(`${AURA_API_BASE}/api/profile`, {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  })

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error("Invalid token")
    }
    throw new Error(`Failed to fetch profile: ${response.status}`)
  }

  const data = (await response.json()) as {
    user?: { email?: string; name?: string }
    email?: string
    name?: string
    organizations?: Organization[]
    selectedOrganizationId?: string | null
    hasPersonalAccount?: boolean | null
  }
  // Backend returns { user: { email, name, ... }, organizations }
  // Transform to flat AuracodeProfile structure
  return {
    email: data.user?.email ?? data.email ?? "",
    name: data.user?.name ?? data.name,
    organizations: data.organizations,
    selectedOrganizationId: data.selectedOrganizationId ?? undefined,
    hasPersonalAccount: data.hasPersonalAccount ?? undefined,
  }
}

/**
 * Alias for compatibility with existing code
 */
export const getAuraProfile = fetchProfile

/**
 * Resolve the organization a fresh login should default to.
 *
 * Applied once at login time (not on every profile fetch): prefer the cloud's
 * validated `selectedOrganizationId`, and fall back to the first organization
 * when the account has no personal account to sit on. Returns `undefined` to
 * mean "personal account".
 */
export function defaultOrganizationId(profile: AuracodeProfile): string | undefined {
  const orgs = profile.organizations ?? []
  const selected = profile.selectedOrganizationId
  const valid = selected && orgs.some((org) => org.id === selected) ? selected : undefined
  return valid ?? (profile.hasPersonalAccount === false ? orgs[0]?.id : undefined)
}

/**
 * Fetch user balance from Aura API
 * @param token - Authentication token
 * @param organizationId - Optional organization ID for team balance
 */
export async function fetchBalance(
  token: string,
  organizationId?: string,
  log: { warn(message: string, extra?: Record<string, unknown>): void } = console,
): Promise<AuracodeBalance | null> {
  try {
    const headers: Record<string, string> = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    }
    if (organizationId) {
      headers["x-auracode-organizationid"] = organizationId
    }

    const response = await fetch(`${AURA_API_BASE}/api/profile/balance`, { headers })

    if (!response.ok) {
      log.warn("Failed to fetch balance", { status: response.status })
      return null
    }

    const data = (await response.json()) as { balance?: number }
    return { balance: data.balance ?? 0 }
  } catch (error) {
    log.warn("Error fetching balance", { error })
    return null
  }
}

/**
 * Alias for compatibility with existing code
 */
export const getAuraBalance = fetchBalance

/**
 * Fetch default model for a given organization context
 * When token is provided, returns the authenticated user's default model
 * When no token is provided, returns the default free model for anonymous usage
 */
export async function fetchDefaultModel(
  token?: string,
  organizationId?: string,
  fallback = token ? DEFAULT_MODEL : DEFAULT_FREE_MODEL,
): Promise<string> {
  const path = organizationId ? `/api/organizations/${organizationId}/defaults` : `/api/defaults`
  const url = `${AURA_API_BASE}${path}`

  try {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }
    if (token) {
      headers.Authorization = `Bearer ${token}`
    }

    const response = await fetch(url, { headers })

    if (!response.ok) {
      return fallback
    }

    const data = (await response.json()) as { defaultModel?: string; defaultFreeModel?: string }
    if (token) {
      return data.defaultModel || fallback
    }
    return data.defaultFreeModel || fallback
  } catch {
    return fallback
  }
}

/**
 * Alias for compatibility with existing code
 */
export const getAuraDefaultModel = fetchDefaultModel

/**
 * Fetch both profile and balance in parallel
 */
export async function fetchProfileWithBalance(token: string): Promise<{
  profile: AuracodeProfile
  balance: AuracodeBalance | null
}> {
  const [profile, balance] = await Promise.all([fetchProfile(token), fetchBalance(token)])
  return { profile, balance }
}

/**
 * Prompt user to select an organization or personal account
 * @param organizations List of organizations the user belongs to
 * @returns Organization ID or undefined for personal account
 */
export async function promptOrganizationSelection(organizations: Organization[]): Promise<string | undefined> {
  if (!organizations || organizations.length === 0) {
    return undefined
  }

  const choices = [
    { label: "Personal Account", value: "personal", hint: "Use your personal account" },
    ...organizations.map((org) => ({
      label: org.name,
      value: org.id,
      hint: `Organization`,
    })),
  ]

  const result = await select({
    message: "Select account",
    options: choices,
  })

  if (result === "personal") {
    return undefined
  }

  return result as string
}
