import {
  DiffLineAnnotation,
  FileContents,
  FileDiffMetadata,
  FileDiffOptions,
  type SelectedLineRange,
} from "@pierre/diffs"
import { ComponentProps } from "solid-js"
import { createDefaultOptions as defaults, styleVariables } from "@opencode-ai/ui/pierre"

export { styleVariables }

export interface DiffHandle {
  scrollToLine: (line: number, side: "additions" | "deletions") => boolean
}

// Character matching fragments inserted identifiers when they share letters with
// existing symbols. Word-alt keeps those logical additions visually intact.
export const LINE_DIFF_TYPE = "word-alt" as const

// A file this large renders through Pierre's line virtualizer instead of being
// drawn in one pass. The review panel open policy shares these limits so eager
// and virtualized diffs agree on what counts as extreme.
export const EXTREME_DIFF_CHANGED_LINES = 2_000
export const MAX_EAGER_DIFF_BYTES = 256 * 1024

function bytes(lines: string[]) {
  return lines.reduce((total, line) => total + line.length, 0)
}

// Inline transcript diffs are hunk-bounded, so Pierre can render them once and
// keep the same instance while the tool streams. Only extreme files fall back
// to Pierre's line virtualizer, which resets on every update.
export function virtualize(diff: FileDiffMetadata | undefined) {
  if (!diff) return true
  if (diff.additionLines.length + diff.deletionLines.length > EXTREME_DIFF_CHANGED_LINES) return true
  return bytes(diff.additionLines) > MAX_EAGER_DIFF_BYTES || bytes(diff.deletionLines) > MAX_EAGER_DIFF_BYTES
}

// Keep Aura semantic surfaces at the computed row level. Pierre's dedicated
// number override keeps deletion bars red without tinting line-number text.
const css = `
:host {
  --diffs-fg-number-deletion-override: var(--diffs-fg-number-override, var(--diffs-fg));
  --diffs-bg-deletion-override: var(--surface-diff-delete-base, var(--diffs-deletion-base));
}
[data-indicators='bars'] [data-column-number][data-line-type='change-deletion'] {
  --diffs-deletion-base: var(--surface-diff-delete-strong, #ff6762);
}
[data-diff][data-background] [data-line][data-line-type='change-addition'] {
  --diffs-computed-diff-line-bg: var(--surface-diff-add-base, var(--diffs-bg-addition));
  --diffs-computed-selected-line-bg: var(--surface-diff-add-base, var(--diffs-bg-addition));
}
[data-diff][data-background] [data-column-number][data-line-type='change-addition'] {
  --diffs-computed-diff-line-bg: var(--surface-diff-add-weaker, var(--diffs-bg-addition-number));
  --diffs-computed-selected-line-bg: var(--surface-diff-add-weaker, var(--diffs-bg-addition-number));
}
[data-diff][data-background] [data-line][data-line-type='change-deletion'] {
  --diffs-computed-diff-line-bg: var(--surface-diff-delete-base, var(--diffs-bg-deletion));
  --diffs-computed-selected-line-bg: var(--surface-diff-delete-base, var(--diffs-bg-deletion));
}
[data-diff][data-background] [data-column-number][data-line-type='change-deletion'] {
  --diffs-computed-diff-line-bg: var(--surface-diff-delete-weaker, var(--diffs-bg-deletion-number));
  --diffs-computed-selected-line-bg: var(--surface-diff-delete-weaker, var(--diffs-bg-deletion-number));
}
`

export function createDefaultOptions<T>(style: FileDiffOptions<T>["diffStyle"]) {
  const opts = defaults<T>(style)
  return {
    ...opts,
    diffIndicators: "bars" as const,
    lineDiffType: LINE_DIFF_TYPE,
    unsafeCSS: `${opts.unsafeCSS}\n${css}`,
  }
}

// Extends upstream DiffProps with a `fileDiff` variant so Pierre can render
// a precomputed FileDiffMetadata directly. The pair (before/after) variant
// stays compatible with upstream usage.
type DiffShared<T> = FileDiffOptions<T> & {
  annotations?: DiffLineAnnotation<T>[]
  selectedLines?: SelectedLineRange | null
  commentedLines?: SelectedLineRange[]
  onLineNumberSelectionEnd?: (selection: SelectedLineRange | null) => void
  onRendered?: () => void
  visible?: boolean
  handle?: (handle: DiffHandle | undefined) => void
  scrollTo?: (offset: number) => void
  // When false, render the supplied diff once instead of row-virtualizing it.
  // Callers should supply hunk-bounded `fileDiff`/`patch` data for large source
  // files so eager rendering does not expand full before/after content.
  // Defaults to virtualized.
  virtualized?: boolean
  // Stable rendered-content identity used to preserve deferred height when a
  // surrounding row virtualizer unmounts and later re-creates this diff.
  sizeKey?: object
  class?: string
  classList?: ComponentProps<"div">["classList"]
}

type DiffPair<T> = DiffShared<T> & {
  before: FileContents
  after: FileContents
  /** Unified patch used to parse only rendered hunks instead of full file contents. */
  patch?: string
  fileDiff?: undefined
}

type DiffPatch<T> = DiffShared<T> & {
  fileDiff: FileDiffMetadata
  before?: undefined
  after?: undefined
  patch?: undefined
}

export type DiffProps<T = {}> = DiffPair<T> | DiffPatch<T>
