/**
 * Re-export Lucide icons for consumers of @auracode/aura-ui.
 * Only add icons here that are actually used — esbuild/Vite will
 * tree-shake unused exports but explicit re-exports keep the API small.
 */
export { default as WandSparkles } from "lucide-solid/icons/wand-sparkles"
