export * from "@opencode-ai/ui/i18n/da"
