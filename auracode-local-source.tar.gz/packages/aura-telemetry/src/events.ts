export enum TelemetryEvent {
  // CLI Lifecycle
  CLI_START = "CLI Start",
  CLI_EXIT = "CLI Exit",

  // Session Events
  SESSION_START = "Session Start",
  SESSION_END = "Session End",
  SESSION_MESSAGE = "Session Message",

  // Model Usage
  LLM_COMPLETION = "LLM Completion",

  // Feature Usage
  COMMAND_USED = "Command Used",
  TOOL_USED = "Tool Used",
  AGENT_USED = "Agent Used",
  PLAN_FOLLOWUP = "Plan Followup",
  SUGGESTION_SHOWN = "Suggestion Shown",
  SUGGESTION_ACCEPTED = "Suggestion Accepted",

  // Code Indexing
  INDEXING_STARTED = "Indexing Started",
  INDEXING_COMPLETED = "Indexing Completed",
  INDEXING_FILE_COUNT = "Indexing File Count",
  INDEXING_BATCH_RETRY = "Indexing Batch Retry",
  INDEXING_ERROR = "Indexing Error",

  // Share Events
  SHARE_CREATED = "Share Created",
  SHARE_DELETED = "Share Deleted",

  // MCP Events
  MCP_SERVER_CONNECTED = "MCP Server Connected",
  MCP_SERVER_ERROR = "MCP Server Error",
  MCP_AUTH_STARTED = "MCP Auth Started",
  MCP_AUTH_COMPLETED = "MCP Auth Completed",

  // Remote Events
  REMOTE_CONNECTION_OPENED = "Remote Connection Opened",

  // Auth Events
  AUTH_SUCCESS = "Auth Success",
  AUTH_LOGOUT = "Auth Logout",

  // Config Events
  TELEMETRY_DISABLED = "Telemetry Disabled",

  // Feedback
  FEEDBACK_SUBMITTED = "Feedback Submitted",

  // Errors
  ERROR = "Error",
}
