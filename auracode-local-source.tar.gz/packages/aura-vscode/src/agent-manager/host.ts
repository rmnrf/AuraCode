/**
 * Host interface — abstracts all VS Code capabilities the Agent Manager needs.
 *
 * Implemented by vscode-host.ts using real VS Code APIs. Alternative
 * implementations (Tauri, web, CLI) can provide their own adapter.
 *
 * No file in src/agent-manager/ should import "vscode" except the adapter
 * files listed in the architecture test allowlist.
 */

import type { Session } from "@auracode/sdk/v2/client"
import type { ProjectRef, SessionRef, WorktreeRef } from "./project/route"
import type { PRMergeMethod } from "./types"

// ---------------------------------------------------------------------------
// Primitives
// ---------------------------------------------------------------------------

export interface Disposable {
  dispose(): void
}

// ---------------------------------------------------------------------------
// Output channel
// ---------------------------------------------------------------------------

export interface OutputHandle {
  appendLine(msg: string): void
  /** Reveal the channel, e.g. after writing a report the user asked for. */
  show?(): void
  dispose(): void
}

// ---------------------------------------------------------------------------
// Session provider (abstracts AuraProvider interactions)
// ---------------------------------------------------------------------------

export interface SessionProvider {
  setSessionDirectory(id: string, directory: string): void
  clearSessionDirectory(id: string): void
  getSessionDirectories(): ReadonlyMap<string, string>
  getSessionInfo?(id: string): Promise<Session | undefined>
  /** List root sessions (no parent) whose directory exactly matches `dir`. */
  listSessions?(dir: string): Promise<Session[]>
  trackSession(id: string): void
  refreshSessions(): void
  registerSession(session: Session): void
  /** Recover any pending permission/question prompts for tracked sessions. */
  recoverPendingPrompts(): void
  /** Register a callback invoked when a plan follow-up session is adopted.
   *  The callback receives the new session and its directory so the Agent Manager
   *  can route it to the correct worktree instead of LOCAL. */
  onFollowupAdopted(cb: (session: Session, directory: string) => void): void
  acknowledgeDraft(draftID: string, sessionID: string): void
  abortSessions(ids: readonly string[]): Promise<void>
  showMemory(sessionID?: string): Promise<void>
  toggleMemory(sessionID?: string): Promise<void>
  /** Register a project root with the shared route service. */
  registerProjectRoute?(ref: ProjectRef, root: string, generation: number): void
  /** Drop a project and all its session/worktree routes. */
  unregisterProjectRoute?(projectId: string): void
  /** Register a worktree directory under a project. */
  registerWorktreeRoute?(ref: WorktreeRef, directory: string, generation: number): void
  /** Register a session directory under a project (exact routing). */
  registerSessionRoute?(ref: SessionRef, directory: string, generation: number): void
  /** Drop one session route (keeps the raw ambiguity index consistent). */
  unregisterSessionRoute?(ref: SessionRef): void
  /** Whether a raw session id is known to be ambiguous across projects. */
  isSessionRouteAmbiguous?(sessionId: string): boolean
  /** Exact directory for a project-qualified session ref, or undefined. */
  routeSessionDirectoryFor?(ref: SessionRef): string | undefined
  /** Re-check Git capability for the active project/session directory. */
  refreshGitStatus?(): void
  retryInitialization?(): void
  dispose(): void
}

// ---------------------------------------------------------------------------
// Host — the single interface for all platform capabilities
// ---------------------------------------------------------------------------

/** Result of opening a panel — bundles the messaging handle + session provider. */
export interface PanelContext {
  /** Send a message to the webview. */
  postMessage(msg: unknown): void

  /** Resolve once the panel webview is ready to receive messages. */
  waitForReady(): Promise<void>

  /** Resolve once the panel is the active editor tab. */
  waitForActive(): Promise<void>

  /** Reveal the panel. */
  reveal(preserveFocus?: boolean): void

  /** Whether the panel is currently the active tab. */
  readonly active: boolean

  /** Whether the panel is visible (may be unfocused in a split editor group). */
  readonly visible: boolean

  /** Session provider wired to this panel. */
  readonly sessions: SessionProvider

  /** Register a callback for when panel visibility changes. */
  onDidChangeVisibility(cb: (visible: boolean) => void): Disposable

  /** Register a callback for when the panel is disposed. */
  onDidDispose(cb: () => void): Disposable

  /** Dispose the panel and all associated resources. */
  dispose(): void
}

export interface Host {
  /**
   * Create (or restore) a webview panel wired with a session provider.
   * The host handles HTML generation, icon paths, CSP, and AuraProvider setup.
   *
   * @param opts.onBeforeMessage — interceptor for messages from the webview
   */
  openPanel(opts: {
    onBeforeMessage: (msg: Record<string, unknown>) => Promise<Record<string, unknown> | null>
    worktreeDirectories?: () => string[]
    /** Dynamic root directory for the panel's session provider (follows the active project). */
    workspaceRoot?: () => string | undefined
    projectId?: () => string | undefined
    /** Source of an externally created session, including async background work. */
    sessionProject?: () => string | undefined
  }): PanelContext

  /** Get the workspace/project root path. */
  workspacePath(): string | undefined

  /** Local files with unsaved editor changes. */
  dirtyFiles(): string[]

  /** Show a folder picker and return the selected path, or undefined when cancelled. */
  pickFolder(opts?: { defaultPath?: string; title?: string }): Promise<string | undefined>

  input(opts: {
    title: string
    prompt?: string
    value?: string
    validate?: (value: string) => string | undefined
  }): Promise<string | undefined>

  /** Show a native modal confirmation. Dismissal means no. */
  confirm(message: string, action: string): Promise<boolean>

  /** Clone without changing workspace membership; return the verified checkout path. */
  cloneRepository(url: string, parent: string): Promise<string | undefined>

  browserAutomation(): boolean
  approveBrowserNavigation?(origin: string): Promise<boolean>

  /** Whether background worktree pre-warming is enabled. */
  worktreePool(): boolean

  /** Listen for changes to the worktree pre-warming setting. */
  onDidChangeWorktreePool(cb: (enabled: boolean) => void): Disposable

  /** Read the persisted additional-project registry payload. */
  readProjects(): unknown

  /** Persist the additional-project registry payload. */
  writeProjects(value: unknown): Promise<void>

  /** Read and persist the user's last PR merge method per repository. */
  getPRMergeMethod?(repo: string): PRMergeMethod | undefined
  savePRMergeMethod?(repo: string, method: PRMergeMethod): Promise<void>

  unregisterProjectRoutes(projectId: string): void

  /** Subscribe to workspace folder changes (pinned project re-derivation). */
  onDidChangeWorkspaceFolders(cb: () => void): Disposable

  /** Whether the workspace permits executing configured scripts. */
  isTrusted(): boolean

  /** Read the user's automatic branch naming preferences. */
  autoBranchNaming(): { enabled: boolean; prefix: string }

  /** Show an error notification. */
  showError(msg: string): void

  /** Show an info, warning, or error notification. */
  notify(kind: "info" | "warning" | "error", msg: string): void

  /** Reveal a path in the OS file manager. A no-op (logged) on a remote workspace. */
  revealInOS(path: string): void

  /** Run a cancellable background task behind a progress notification. */
  withProgress<T>(title: string, task: (cancelled: () => boolean) => Promise<T>): Promise<T>

  /** Open a text document in an editor (e.g. setup script). */
  openDocument(path: string): Promise<void>

  /** Open a file at a specific location in the editor. */
  openFile(path: string, line?: number, column?: number): void

  /** Open a folder (optionally in a new window). */
  openFolder(path: string, newWindow: boolean): void

  /** Create an output channel for logging. */
  createOutput(name: string): OutputHandle

  /** Read extension keybindings, with the user's keybindings.json applied. */
  extensionKeybindings(): Array<{ command: string; key?: string; mac?: string; when?: string }>

  /** Notify when the user's keybindings.json changes. */
  onDidChangeKeybindings?(cb: () => void): Disposable

  /** Copy text to the system clipboard. */
  copyToClipboard(text: string): void | Promise<void>
  readClipboard?(): Promise<string>

  /** Capture a telemetry event. */
  capture(event: string, properties?: Record<string, unknown>): void

  /** Open a URL in the user's default browser. */
  openExternal(url: string): void

  /** Open Aura Settings, optionally focused on a tab and project. */
  openSettings(tab?: string, projectId?: string): void

  /** Ask VS Code's git extension to re-scan repositories (e.g. after worktree ref migration). */
  refreshGit(): void

  /** Dispose all host resources. */
  dispose(): void
}
