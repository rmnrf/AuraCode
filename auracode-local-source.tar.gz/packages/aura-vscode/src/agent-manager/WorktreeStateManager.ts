/**
 * WorktreeStateManager - Centralized persistent state for agent manager worktrees and sessions.
 *
 * Persists to `.aura/agent-manager.json`. Decouples worktrees from sessions
 * (many sessions per worktree) and provides CRUD operations for both.
 *
 * Data model:
 * - Worktree: a git worktree with branch, path, parentBranch (bare), remote
 * - ManagedSession: a server session ID associated with a worktree (or null for local)
 */

import * as path from "path"
import * as fs from "fs"
import { pathKey } from "./project/paths"
import type { SidebarTarget } from "./project/route"

/** Accept a persisted sidebar target only when its shape matches a known kind. */
function validTarget(value: unknown): SidebarTarget | undefined {
  if (!value || typeof value !== "object") return undefined
  const target = value as Record<string, unknown>
  if (typeof target.projectId !== "string") return undefined
  if (target.kind === "local") return { projectId: target.projectId, kind: "local" }
  if (target.kind === "worktree" && typeof target.worktreeId === "string") {
    return { projectId: target.projectId, kind: "worktree", worktreeId: target.worktreeId }
  }
  if (target.kind === "session" && typeof target.sessionId === "string") {
    return { projectId: target.projectId, kind: "session", sessionId: target.sessionId }
  }
  return undefined
}

export interface Worktree {
  id: string
  branch: string
  path: string
  /** Bare branch name (e.g. "main"), without remote prefix. */
  parentBranch: string
  /** Remote name (e.g. "origin"). When set, diffs compare against `${remote}/${parentBranch}`. */
  remote?: string
  createdAt: string
  /** Shared identifier for worktrees created together via multi-version mode. */
  groupId?: string
  /** User-provided display name for the worktree. */
  label?: string
  /** Cached PR number for instant badge display on reload. */
  prNumber?: number
  /** Cached PR URL for instant badge display on reload. */
  prUrl?: string
  /** Cached PR state for correct badge color on reload (open/merged/closed/draft). */
  prState?: string
  /** Original branch created with the worktree, used for cleanup after a manual branch change. */
  originalBranch?: string
  /** Whether Agent Manager created and may safely clean up this branch. Undefined preserves legacy behavior. */
  branchOwned?: boolean
  /** Initial session whose prompts may name this placeholder branch once. */
  autoNameSessionId?: string
  /** Number of prompts observed for the armed session; bounds rename attempts. */
  autoNamePromptCount?: number
  /** Section this worktree belongs to, or undefined for ungrouped. */
  sectionId?: string
  /** Pinned worktrees show at the top of the sidebar. The section is kept for when the pin is removed. */
  pinned?: boolean
}

export interface Section {
  id: string
  name: string
  /** Color label (e.g. "Red", "Blue") mapped to VS Code theme CSS vars at render time, or null for default. */
  color: string | null
  /** Position among sections. Ungrouped worktrees are always rendered above sections. */
  order: number
  collapsed: boolean
}

/**
 * Construct the remote-prefixed ref for diff comparisons.
 * Returns `${remote}/${branch}` when a remote is known, otherwise the bare branch.
 * This mirrors Superset's pattern of always diffing against the remote tracking ref.
 */
export function remoteRef(wt: Pick<Worktree, "parentBranch" | "remote">): string {
  return wt.remote ? `${wt.remote}/${wt.parentBranch}` : wt.parentBranch
}

export interface ManagedSession {
  id: string
  worktreeId: string | null
  createdAt: string
}

interface StateFile {
  worktrees: Record<string, Omit<Worktree, "id">>
  sessions: Record<string, Omit<ManagedSession, "id">>
  closedSessions?: Record<string, string | null>
  sections?: Record<string, Omit<Section, "id">>
  tabOrder?: Record<string, string[]>
  pinnedTabs?: Record<string, string[]>
  worktreeOrder?: string[]
  sessionsCollapsed?: boolean
  sidebarCollapsed?: boolean
  reviewDiffStyle?: "unified" | "split"
  defaultBaseBranch?: string
  activeTarget?: SidebarTarget
}

export type StateLoadStatus = "loaded" | "missing" | "failed"

export interface StateLoadResult extends MigrationResult {
  status: StateLoadStatus
}

import { AURA_DIR, migrateAgentManagerData, type MigrationResult } from "./constants"

const STATE_FILE = "agent-manager.json"
const CLOSED_LIMIT = 1_000

let counter = 0

function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${++counter}`
}

export class WorktreeStateManager {
  private readonly file: string
  private worktrees = new Map<string, Worktree>()
  private sessions = new Map<string, ManagedSession>()
  private closed = new Map<string, string | null>()
  private sections = new Map<string, Section>()
  private tabOrder: Record<string, string[]> = {}
  private pinnedTabs: Record<string, string[]> = {}
  private worktreeOrder: string[] = []
  private collapsed = true
  private sidebar = false
  private reviewDiffStyle: "unified" | "split" = "unified"
  private defaultBase: string | undefined
  private activeTarget: SidebarTarget | undefined
  private readonly log: (msg: string) => void
  private saving: Promise<void> | undefined
  private dirty = false
  private failed = false

  private readonly root: string
  private migrated = false
  private loadFailed = false

  constructor(root: string, log: (msg: string) => void) {
    this.root = root
    this.file = path.join(root, AURA_DIR, STATE_FILE)
    this.log = log
  }

  // ---------------------------------------------------------------------------
  // Queries
  // ---------------------------------------------------------------------------

  getWorktrees(): Worktree[] {
    return [...this.worktrees.values()]
  }

  getWorktree(id: string): Worktree | undefined {
    return this.worktrees.get(id)
  }

  /**
   * Find worktree by its filesystem path.
   *
   * Compares with `pathKey`, so a symlinked parent (`/tmp` -> `/private/tmp` on macOS) or a case
   * variant still finds the row. A lexical compare misses both, and every caller uses the answer to
   * decide which worktree a session, a terminal, or a tool call belongs to.
   */
  findWorktreeByPath(wtPath: string): Worktree | undefined {
    const target = pathKey(wtPath)
    for (const wt of this.worktrees.values()) {
      if (pathKey(wt.path) === target) return wt
    }
    return undefined
  }

  getSessions(worktreeId?: string): ManagedSession[] {
    const all = [...this.sessions.values()]
    if (worktreeId === undefined) return all
    return all.filter((s) => s.worktreeId === worktreeId)
  }

  getSession(id: string): ManagedSession | undefined {
    return this.sessions.get(id)
  }

  isSessionClosed(id: string): boolean {
    return this.closed.has(id)
  }

  /** Returns the worktree directory for a session, or undefined for local sessions. */
  directoryFor(sessionId: string): string | undefined {
    const session = this.sessions.get(sessionId)
    if (!session?.worktreeId) return undefined
    return this.worktrees.get(session.worktreeId)?.path
  }

  /** Returns all session IDs that belong to any worktree. */
  worktreeSessionIds(): Set<string> {
    const ids = new Set<string>()
    for (const s of this.sessions.values()) {
      if (s.worktreeId) ids.add(s.id)
    }
    return ids
  }

  // ---------------------------------------------------------------------------
  // Mutations
  // ---------------------------------------------------------------------------

  addWorktree(params: {
    branch: string
    path: string
    parentBranch: string
    remote?: string
    groupId?: string
    label?: string
    branchOwned?: boolean
  }): Worktree {
    const id = generateId("wt")
    const wt: Worktree = {
      id,
      branch: params.branch,
      path: params.path,
      parentBranch: params.parentBranch,
      createdAt: new Date().toISOString(),
    }
    if (params.remote) wt.remote = params.remote
    if (params.groupId) wt.groupId = params.groupId
    if (params.label) wt.label = params.label
    if (params.branchOwned !== undefined) wt.branchOwned = params.branchOwned
    this.worktrees.set(id, wt)
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    this.log(
      `Added worktree ${id}: ${params.branch}${params.label ? ` (label=${params.label})` : ""}${params.groupId ? ` (group=${params.groupId})` : ""}`,
    )
    void this.save()
    return wt
  }

  restoreWorktree(params: {
    branch: string
    path: string
    parentBranch: string
    remote?: string
    createdAt: string
  }): Worktree {
    const existing = this.findWorktreeByPath(params.path)
    if (existing) return existing
    const id = generateId("wt")
    const wt: Worktree = {
      id,
      branch: params.branch,
      path: params.path,
      parentBranch: params.parentBranch,
      createdAt: params.createdAt,
    }
    if (params.remote) wt.remote = params.remote
    this.worktrees.set(id, wt)
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    this.log(`Restored worktree ${id}: ${params.branch} (${params.path})`)
    void this.save()
    return wt
  }

  updateWorktreeBranch(id: string, branch: string): boolean {
    const wt = this.worktrees.get(id)
    if (!wt || wt.branch === branch) return false
    if (!wt.originalBranch && wt.branchOwned !== false) wt.originalBranch = wt.branch
    this.log(`Updated worktree ${id} branch: ${wt.branch} → ${branch}`)
    wt.branch = branch
    wt.autoNameSessionId = undefined
    wt.autoNamePromptCount = undefined
    void this.save()
    return true
  }

  armAutoName(id: string, sessionId: string): void {
    const wt = this.worktrees.get(id)
    if (!wt || wt.branchOwned !== true) return
    wt.autoNameSessionId = sessionId
    wt.autoNamePromptCount = 0
    void this.save()
  }

  clearAutoName(id: string): void {
    const wt = this.worktrees.get(id)
    if (!wt?.autoNameSessionId) return
    wt.autoNameSessionId = undefined
    wt.autoNamePromptCount = undefined
    void this.save()
  }

  /** Increment the prompt counter for an armed worktree and return the new
   *  count, or undefined when the worktree is no longer armed. */
  incrementAutoNameCount(id: string): number | undefined {
    const wt = this.worktrees.get(id)
    if (!wt?.autoNameSessionId) return undefined
    wt.autoNamePromptCount = (wt.autoNamePromptCount ?? 0) + 1
    void this.save()
    return wt.autoNamePromptCount
  }

  renameOwnedBranch(id: string, current: string, branch: string): boolean {
    const wt = this.worktrees.get(id)
    if (!wt || wt.branch !== current || wt.branchOwned !== true) return false
    wt.branch = branch
    wt.originalBranch = undefined
    wt.autoNameSessionId = undefined
    wt.autoNamePromptCount = undefined
    this.log(`Automatically renamed worktree ${id} branch: ${current} → ${branch}`)
    void this.save()
    return true
  }

  updateWorktreeLabel(id: string, label: string): void {
    const wt = this.worktrees.get(id)
    if (!wt) return
    wt.label = label || undefined
    this.log(`Updated worktree ${id} label to "${label}"`)
    void this.save()
  }

  /** Pin or unpin a worktree. Multi-version siblings follow so the group stays together. */
  setWorktreePinned(id: string, pinned: boolean): void {
    const wt = this.worktrees.get(id)
    if (!wt) return
    for (const item of this.worktrees.values()) {
      if (item.id !== id && (!wt.groupId || item.groupId !== wt.groupId)) continue
      item.pinned = pinned || undefined
    }
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    void this.save()
  }

  updateWorktreePR(id: string, prNumber?: number, prUrl?: string, prState?: string): void {
    const wt = this.worktrees.get(id)
    if (!wt) return
    if (wt.prNumber === prNumber && wt.prUrl === prUrl && wt.prState === prState) return
    wt.prNumber = prNumber
    wt.prUrl = prUrl
    wt.prState = prState
    void this.save()
  }

  removeWorktree(id: string): ManagedSession[] {
    const removed = this.worktrees.delete(id)
    if (!removed) return []

    // Collect and remove all sessions belonging to this worktree
    const orphaned: ManagedSession[] = []
    for (const s of this.sessions.values()) {
      if (s.worktreeId === id) {
        orphaned.push({ ...s })
        this.sessions.delete(s.id)
      }
    }

    for (const [session, worktree] of this.closed) {
      if (worktree === id) this.closed.delete(session)
    }

    // Clean up tab order for this worktree
    delete this.tabOrder[id]
    delete this.pinnedTabs[id]

    this.setNormalizedWorktreeOrder(this.worktreeOrder.filter((item) => item !== id))

    this.log(`Removed worktree ${id}, removed ${orphaned.length} sessions`)
    void this.save()
    return orphaned
  }

  addSession(sessionId: string, worktreeId: string | null): ManagedSession {
    this.closed.delete(sessionId)
    const session: ManagedSession = { id: sessionId, worktreeId, createdAt: new Date().toISOString() }
    this.sessions.set(sessionId, session)
    const worktree = worktreeId ? this.worktrees.get(worktreeId) : undefined
    if (worktree?.autoNameSessionId && worktreeId && this.getSessions(worktreeId).length > 1) {
      worktree.autoNameSessionId = undefined
      worktree.autoNamePromptCount = undefined
    }
    this.log(`Added session ${sessionId} to worktree ${worktreeId ?? "local"}`)
    void this.save()
    return session
  }

  /** Move an existing session to a worktree (or back to local when null). */
  moveSession(sessionId: string, worktreeId: string | null): void {
    const session = this.sessions.get(sessionId)
    if (!session) return
    const previous = session.worktreeId ? this.worktrees.get(session.worktreeId) : undefined
    if (previous?.autoNameSessionId === sessionId) {
      previous.autoNameSessionId = undefined
      previous.autoNamePromptCount = undefined
    }
    session.worktreeId = worktreeId
    const worktree = worktreeId ? this.worktrees.get(worktreeId) : undefined
    if (worktree?.autoNameSessionId) {
      worktree.autoNameSessionId = undefined
      worktree.autoNamePromptCount = undefined
    }
    this.log(`Moved session ${sessionId} to ${worktreeId ?? "local"}`)
    void this.save()
  }

  closeSession(id: string, worktreeId: string | null): void {
    this.closed.delete(id)
    this.closed.set(id, worktreeId)
    if (this.closed.size > CLOSED_LIMIT) this.closed.delete(this.closed.keys().next().value!)
    void this.save()
  }

  removeSession(id: string): void {
    this.sessions.delete(id)

    // Remove this session from any tab order arrays
    for (const [key, order] of Object.entries(this.tabOrder)) {
      const idx = order.indexOf(id)
      if (idx !== -1) {
        order.splice(idx, 1)
        if (order.length === 0) delete this.tabOrder[key]
      }
    }

    for (const [key, pinned] of Object.entries(this.pinnedTabs)) {
      const idx = pinned.indexOf(id)
      if (idx !== -1) {
        pinned.splice(idx, 1)
        if (pinned.length === 0) delete this.pinnedTabs[key]
      }
    }

    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Tab order
  // ---------------------------------------------------------------------------

  getTabOrder(): Record<string, string[]> {
    return this.tabOrder
  }

  setTabOrder(key: string, order: string[]): void {
    this.tabOrder[key] = order
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Pinned tabs
  // ---------------------------------------------------------------------------

  getPinnedTabs(): Record<string, string[]> {
    return this.pinnedTabs
  }

  /** Pinned session ids for one context, in pin order. An empty list clears the key. */
  setPinnedTabs(key: string, ids: string[]): void {
    if (ids.length === 0) {
      delete this.pinnedTabs[key]
      void this.save()
      return
    }
    this.pinnedTabs[key] = ids
    void this.save()
  }

  /** Last selected sidebar target (Local/worktree/session) for seamless restore. */
  getActiveTarget(): SidebarTarget | undefined {
    return this.activeTarget
  }

  setActiveTarget(target: SidebarTarget | undefined): void {
    const cur = this.activeTarget
    const same =
      cur?.kind === target?.kind &&
      cur?.projectId === target?.projectId &&
      (cur?.kind !== "worktree" || target?.kind !== "worktree" || cur.worktreeId === target.worktreeId) &&
      (cur?.kind !== "session" || target?.kind !== "session" || cur.sessionId === target.sessionId)
    if (same) return
    this.activeTarget = target
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Worktree order
  // ---------------------------------------------------------------------------

  getWorktreeOrder(): string[] {
    return this.worktreeOrder
  }

  setWorktreeOrder(order: string[]): void {
    this.setNormalizedWorktreeOrder(order)
    void this.save()
  }

  /** Top-level worktrees: ungrouped and pinned. Pinned worktrees render above sections. */
  private top(id: string): boolean {
    const wt = this.worktrees.get(id)
    return !!wt && (!wt.sectionId || wt.pinned === true)
  }

  private ordered(order: string[]): string[] {
    const idx = new Map(order.map((id, i) => [id, i] as const))
    return [...this.worktrees.values()]
      .filter((wt) => this.top(wt.id))
      .sort((a, b) => (idx.get(a.id) ?? Number.MAX_SAFE_INTEGER) - (idx.get(b.id) ?? Number.MAX_SAFE_INTEGER))
      .map((wt) => wt.id)
  }

  private setNormalizedWorktreeOrder(order: string[]): boolean {
    const valid = new Set<string>()
    for (const sec of this.sections.values()) valid.add(sec.id)
    for (const wt of this.worktrees.values()) valid.add(wt.id)

    const result: string[] = []
    const seen = new Set<string>()
    const add = (id: string) => {
      if (!valid.has(id) || seen.has(id)) return
      result.push(id)
      seen.add(id)
    }

    for (const id of order) add(id)
    for (const sec of [...this.sections.values()].sort((a, b) => a.order - b.order)) add(sec.id)
    for (const wt of this.worktrees.values()) add(wt.id)

    const normalized = [
      ...this.ordered(result),
      ...result.filter((id) => this.sections.has(id)),
      ...result.filter((id) => this.worktrees.has(id) && !this.top(id)),
    ]

    const changed =
      normalized.length !== this.worktreeOrder.length || normalized.some((id, idx) => id !== this.worktreeOrder[idx])
    this.worktreeOrder = normalized
    return this.syncSectionOrder() || changed
  }

  private syncSectionOrder(): boolean {
    const top = this.worktreeOrder.filter((id) => {
      if (this.sections.has(id)) return true
      return false
    })
    const index = new Map(top.map((id, idx) => [id, idx] as const))
    const changes = [...this.sections.values()].map((sec) => {
      const order = index.get(sec.id)
      if (order === undefined || sec.order === order) return false
      sec.order = order
      return true
    })
    return changes.some(Boolean)
  }

  // ---------------------------------------------------------------------------
  // Sections
  // ---------------------------------------------------------------------------

  getSections(): Section[] {
    return [...this.sections.values()].sort((a, b) => a.order - b.order)
  }

  getSection(id: string): Section | undefined {
    return this.sections.get(id)
  }

  /** Return IDs of worktrees assigned to the given section. */
  getWorktreesInSection(id: string): string[] {
    const result: string[] = []
    for (const wt of this.worktrees.values()) {
      if (wt.sectionId === id) result.push(wt.id)
    }
    return result
  }

  addSection(name: string, color: string | null, worktreeIds?: string[]): Section {
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    const id = generateId("sec")
    const order = this.worktreeOrder.filter((item) => {
      if (this.sections.has(item)) return true
      const wt = this.worktrees.get(item)
      return !!wt && !wt.sectionId
    }).length
    const sec: Section = { id, name, color, order, collapsed: false }
    this.sections.set(id, sec)
    this.worktreeOrder.push(id)
    if (worktreeIds) {
      for (const wtId of worktreeIds) {
        const wt = this.worktrees.get(wtId)
        if (wt) wt.sectionId = id
      }
    }
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    this.log(`Added section ${id}: "${name}"`)
    void this.save()
    return sec
  }

  renameSection(id: string, name: string): void {
    const sec = this.sections.get(id)
    if (!sec || !name) return
    sec.name = name
    this.log(`Renamed section ${id} to "${name}"`)
    void this.save()
  }

  setSectionColor(id: string, color: string | null): void {
    const sec = this.sections.get(id)
    if (!sec) return
    sec.color = color
    void this.save()
  }

  toggleSection(id: string): void {
    const sec = this.sections.get(id)
    if (!sec) return
    sec.collapsed = !sec.collapsed
    void this.save()
  }

  deleteSection(id: string): void {
    if (!this.sections.delete(id)) return
    // Ungroup all worktrees in this section — do NOT delete them
    for (const wt of this.worktrees.values()) {
      if (wt.sectionId === id) wt.sectionId = undefined
    }
    this.setNormalizedWorktreeOrder(this.worktreeOrder.filter((item) => item !== id))
    this.log(`Deleted section ${id}, ungrouped its worktrees`)
    void this.save()
  }

  moveSection(id: string, dir: -1 | 1): void {
    const repaired = this.setNormalizedWorktreeOrder(this.worktreeOrder)
    const top = this.worktreeOrder.filter((item) => {
      if (this.sections.has(item)) return true
      const wt = this.worktrees.get(item)
      return !!wt && !wt.sectionId
    })
    const idx = top.indexOf(id)
    const next = idx + dir
    if (idx === -1 || next < 0 || next >= top.length) {
      if (repaired) void this.save()
      return
    }
    const target = top[next]!
    const result = [...this.worktreeOrder]
    const fi = result.indexOf(id)
    if (fi === -1 || result.indexOf(target) === -1) {
      if (repaired) void this.save()
      return
    }
    result.splice(fi, 1)
    const insertAt = result.indexOf(target) + (dir === 1 ? 1 : 0)
    result.splice(insertAt, 0, id)
    this.setNormalizedWorktreeOrder(result)
    void this.save()
  }

  moveToSection(worktreeIds: string[], sectionId: string | null): void {
    // Expand to include all multi-version siblings (same groupId)
    const expanded = new Set(worktreeIds)
    for (const wtId of worktreeIds) {
      const wt = this.worktrees.get(wtId)
      if (!wt?.groupId) continue
      for (const sibling of this.worktrees.values()) {
        if (sibling.groupId === wt.groupId) expanded.add(sibling.id)
      }
    }
    for (const wtId of expanded) {
      const wt = this.worktrees.get(wtId)
      if (!wt) continue
      wt.sectionId = sectionId ?? undefined
    }
    this.setNormalizedWorktreeOrder(this.worktreeOrder)
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Sessions collapsed
  // ---------------------------------------------------------------------------

  getSessionsCollapsed(): boolean {
    return this.collapsed
  }

  setSessionsCollapsed(value: boolean): void {
    this.collapsed = value
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Sidebar collapsed
  // ---------------------------------------------------------------------------

  getSidebarCollapsed(): boolean {
    return this.sidebar
  }

  setSidebarCollapsed(value: boolean): void {
    this.sidebar = value
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Review diff style
  // ---------------------------------------------------------------------------

  getReviewDiffStyle(): "unified" | "split" {
    return this.reviewDiffStyle
  }

  setReviewDiffStyle(value: "unified" | "split"): void {
    this.reviewDiffStyle = value
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Default base branch
  // ---------------------------------------------------------------------------

  getDefaultBaseBranch(): string | undefined {
    return this.defaultBase
  }

  setDefaultBaseBranch(value: string | undefined): void {
    this.defaultBase = value
    void this.save()
  }

  // ---------------------------------------------------------------------------
  // Persistence
  // ---------------------------------------------------------------------------

  async load(): Promise<StateLoadResult> {
    // Migrate Agent Manager data from .auracode → .aura before first read
    let migration: MigrationResult = { refsFixed: 0 }
    if (!this.migrated) {
      this.migrated = true
      migration = await migrateAgentManagerData(this.root, this.log)
    }
    try {
      const content = await fs.promises.readFile(this.file, "utf-8")
      this.apply(content)
      this.loadFailed = false
      return { ...migration, status: "loaded" }
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code
      if (code === "ENOENT") {
        this.loadFailed = false
        return { ...migration, status: "missing" }
      }
      if (code !== "ENOENT") {
        this.log(`Failed to load state: ${error}`)
        this.loadFailed = true
      }
    }
    return { ...migration, status: "failed" }
  }

  async prepareRecovery(): Promise<boolean> {
    if (!this.loadFailed) return true
    const stamp = new Date().toISOString().replace(/[:.]/g, "-")
    const backup = `${this.file}.corrupt-${stamp}`
    try {
      await fs.promises.rename(this.file, backup)
      this.loadFailed = false
      this.log(`Backed up unreadable state to ${backup}`)
      return true
    } catch (error) {
      this.log(`Failed to back up unreadable state: ${error}`)
      return false
    }
  }

  private apply(content: string): void {
    const data = JSON.parse(content) as StateFile
    this.worktrees.clear()
    this.sessions.clear()
    this.closed.clear()
    this.sections.clear()
    this.tabOrder = {}
    this.pinnedTabs = {}
    this.worktreeOrder = []
    this.reviewDiffStyle = "unified"

    for (const [id, wt] of Object.entries(data.worktrees ?? {})) {
      // Rewrite stale .auracode paths while preserving the separator style already stored.
      const fixed =
        wt.path?.replace(/([/\\])\.auracode([/\\])/g, (_match, leadingSep, trailingSep) => {
          return `${leadingSep}.aura${trailingSep}`
        }) ?? wt.path
      this.worktrees.set(id, { id, ...wt, path: fixed })
    }
    let pruned = 0
    for (const [id, s] of Object.entries(data.sessions ?? {})) {
      const ref = s.worktreeId
      const session: ManagedSession = { id, worktreeId: s.worktreeId, createdAt: s.createdAt }
      if (ref === null) {
        this.sessions.set(id, session)
        continue
      }
      // Skip orphaned sessions referencing a deleted worktree.
      if (!ref || !this.worktrees.has(ref)) {
        pruned++
        continue
      }
      this.sessions.set(id, session)
    }
    this.restoreClosed(data.closedSessions)
    for (const [id, sec] of Object.entries(data.sections ?? {})) {
      this.sections.set(id, { id, ...sec })
    }
    if (data.tabOrder) {
      this.tabOrder = data.tabOrder
    }
    if (data.pinnedTabs) {
      this.pinnedTabs = data.pinnedTabs
    }
    if (data.worktreeOrder) {
      this.worktreeOrder = data.worktreeOrder
    }
    const repaired = this.setNormalizedWorktreeOrder(this.worktreeOrder)
    // State files from before this preference was explicit used the expanded layout.
    this.collapsed = data.sessionsCollapsed ?? false
    this.sidebar = data.sidebarCollapsed ?? false
    if (data.reviewDiffStyle === "split") {
      this.reviewDiffStyle = "split"
    }
    this.defaultBase = data.defaultBaseBranch
    this.activeTarget = validTarget(data.activeTarget)
    this.log(`Loaded state: ${this.worktrees.size} worktrees, ${this.sessions.size} sessions`)
    if (pruned > 0 || repaired) {
      if (pruned > 0) this.log(`Pruned ${pruned} orphaned sessions`)
      void this.save()
    }
  }

  private restoreClosed(value: StateFile["closedSessions"]): void {
    if (!value || typeof value !== "object" || Array.isArray(value)) return
    for (const [id, ref] of Object.entries(value)) {
      if (ref === null || (typeof ref === "string" && this.worktrees.has(ref))) this.closed.set(id, ref)
    }
  }

  /*
   * `validate(root)` used to live here: it removed every worktree row whose directory was missing
   * and deleted the session mappings with it. That silently discarded conversation history for
   * worktrees a user could still restore from their branch, and it never ran — nothing in src/
   * called it. Worktree health now lives in worktree-reconcile.ts, which classifies rows instead of
   * deleting them and only drops a row when the directory, the branch, and the sessions are all
   * gone.
   */

  /** Wait for any in-flight save to complete without triggering a new one. */
  async flush(): Promise<void> {
    const active = this.saving
    if (active) await active
    if (this.dirty) await this.save()
  }

  async save(): Promise<void> {
    if (this.loadFailed) {
      this.log("Skipping save because state failed to load")
      return
    }

    this.dirty = true
    this.failed = false
    while (this.dirty && !this.failed) {
      await (this.saving ?? this.startSave())
    }
  }

  private startSave(): Promise<void> {
    const run = this.drain().finally(() => {
      if (this.saving === run) this.saving = undefined
    })
    this.saving = run
    return run
  }

  private async drain(): Promise<void> {
    while (this.dirty) {
      this.dirty = false
      try {
        await this.writeToDisk()
      } catch (error) {
        this.dirty = true
        this.failed = true
        this.log(`Failed to save state: ${error}`)
        return
      }
    }
  }

  private async writeToDisk(): Promise<void> {
    const data: StateFile = { worktrees: {}, sessions: {} }
    for (const [id, wt] of this.worktrees) {
      const { id: _, ...rest } = wt
      data.worktrees[id] = rest
    }
    for (const [id, s] of this.sessions) {
      const { id: _, ...rest } = s
      data.sessions[id] = rest
    }
    if (this.closed.size > 0) data.closedSessions = Object.fromEntries(this.closed)
    if (this.sections.size > 0) {
      data.sections = {}
      for (const [id, sec] of this.sections) {
        const { id: _, ...rest } = sec
        data.sections[id] = rest
      }
    }
    if (Object.keys(this.tabOrder).length > 0) {
      data.tabOrder = this.tabOrder
    }
    if (Object.keys(this.pinnedTabs).length > 0) {
      data.pinnedTabs = this.pinnedTabs
    }
    if (this.worktreeOrder.length > 0) {
      data.worktreeOrder = this.worktreeOrder
    }
    data.sessionsCollapsed = this.collapsed
    if (this.sidebar) {
      data.sidebarCollapsed = true
    }
    if (this.reviewDiffStyle === "split") {
      data.reviewDiffStyle = "split"
    }
    if (this.defaultBase) {
      data.defaultBaseBranch = this.defaultBase
    }
    if (this.activeTarget) {
      data.activeTarget = this.activeTarget
    }

    const tmp = `${this.file}.${process.pid}.${Date.now()}.tmp`
    try {
      const dir = path.dirname(this.file)
      if (!fs.existsSync(dir)) await fs.promises.mkdir(dir, { recursive: true })
      const content = JSON.stringify(data, null, 2)
      await fs.promises.writeFile(tmp, content, "utf-8")
      await fs.promises.rename(tmp, this.file)
    } catch (error) {
      await fs.promises.rm(tmp, { force: true }).catch((err) => this.log(`Failed to remove temp state file: ${err}`))
      const code = (error as NodeJS.ErrnoException).code
      if (code === "ENOENT") {
        this.log("State directory was removed, skipping save")
        return
      }
      throw error
    }
  }
}
