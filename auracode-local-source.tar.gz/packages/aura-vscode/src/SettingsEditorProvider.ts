import * as vscode from "vscode"
import { AuraProvider } from "./AuraProvider"
import { resolvePanelProjectDirectory } from "./project-directory"
import type { AuraConnectionService } from "./services/cli-backend"
import type { RemoteStatusService } from "./services/RemoteStatusService"
import type { AgentManagerSettingsHandler } from "./aura-provider/options"

type PanelView = "settings" | "profile" | "indexing"

const PANEL_TITLES: Record<PanelView, string> = {
  settings: "Aura Settings",
  profile: "Aura Profile",
  indexing: "Codebase Indexing",
}

/**
 * Opens Settings or Profile as an editor-area WebviewPanel,
 * keeping the sidebar chat undisturbed.
 *
 * Each view type is a singleton panel — calling openPanel() again
 * reveals the existing panel instead of creating a duplicate.
 *
 * Uses a full AuraProvider under the hood so each panel has
 * the same backend connectivity (config, providers, profile, auth)
 * as the sidebar.
 */
export class SettingsEditorProvider implements vscode.Disposable {
  private panels = new Map<PanelView, vscode.WebviewPanel>()
  private providers = new Map<PanelView, AuraProvider>()
  private tabs = new Map<PanelView, string>()
  private subtabs = new Map<PanelView, string>()
  /** Pending deep-link focus (e.g. an MCP server name), consumed after the first navigate it is sent with. */
  private focuses = new Map<PanelView, string>()
  private projects = new Map<PanelView, string>()
  private remoteService: RemoteStatusService | null = null

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly connectionService: AuraConnectionService,
    private readonly context: vscode.ExtensionContext,
    private readonly agentManagerSettings?: AgentManagerSettingsHandler,
  ) {}

  private getProjectDirectory(projectId?: string): string | null {
    if (projectId) return this.agentManagerSettings?.projectDirectory(projectId) ?? null
    const editor = vscode.window.activeTextEditor
    const active =
      editor?.document.uri.scheme === "file"
        ? vscode.workspace.getWorkspaceFolder(editor.document.uri)?.uri.fsPath
        : undefined
    return resolvePanelProjectDirectory(active, vscode.workspace.workspaceFolders)
  }

  /** Extract the PanelView from a viewType string like "aura-code.new.settingsPanel". */
  static viewFromType(type: string): PanelView | undefined {
    const match = type.match(/^aura-code\.new\.(\w+)Panel$/)
    if (!match) return undefined
    const view = match[1] as PanelView
    if (!(view in PANEL_TITLES)) return undefined
    return view
  }

  openPanel(view: PanelView, tab?: string, projectId?: string, subtab?: string, focus?: string): void {
    if (tab) this.tabs.set(view, tab)
    if (subtab) this.subtabs.set(view, subtab)
    if (focus) this.focuses.set(view, focus)
    if (projectId) this.projects.set(view, projectId)
    else this.projects.delete(view)

    const projectDirectory = this.getProjectDirectory(projectId)
    const existing = this.panels.get(view)
    if (existing) {
      this.providers.get(view)?.setProjectDirectory(projectDirectory)
      existing.reveal(vscode.ViewColumn.Active)
      this.providers.get(view)?.postMessage({
        type: "navigate",
        view,
        ...(tab ? { tab } : {}),
        ...(subtab ? { subtab } : {}),
        ...(focus ? { focus } : {}),
        ...(projectId ? { projectId } : {}),
      })
      this.focuses.delete(view)
      return
    }

    const panel = vscode.window.createWebviewPanel(
      `aura-code.new.${view}Panel`,
      PANEL_TITLES[view],
      vscode.ViewColumn.Active,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [this.extensionUri],
      },
    )

    this.wirePanel(panel, view, projectDirectory)
  }

  /** Open (or reveal) the Settings panel and focus its search field. */
  focusSearch(): void {
    this.openPanel("settings")
    const provider = this.providers.get("settings")
    if (!provider) return
    void provider.waitForReady().then(() => {
      provider.postMessage({ type: "action", action: "focusSettingsSearch" })
    })
  }

  /** Re-wire a deserialized panel after extension restart. */
  deserializePanel(panel: vscode.WebviewPanel): void {
    const view = SettingsEditorProvider.viewFromType(panel.viewType)
    if (!view) {
      panel.dispose()
      return
    }
    this.wirePanel(panel, view, this.getProjectDirectory(this.projects.get(view)))
  }

  private wirePanel(panel: vscode.WebviewPanel, view: PanelView, projectDirectory: string | null): void {
    panel.iconPath = {
      light: vscode.Uri.joinPath(this.extensionUri, "assets", "icons", "aura-light.svg"),
      dark: vscode.Uri.joinPath(this.extensionUri, "assets", "icons", "aura-dark.svg"),
    }

    // Create a dedicated AuraProvider for this panel so it has full
    // backend connectivity (config, providers, agents, profile, auth).
    const provider = new AuraProvider(this.extensionUri, this.connectionService, this.context, {
      projectDirectory,
      hideTopBar: true,
      agentManagerSettings: view === "settings" ? this.agentManagerSettings : undefined,
      settingsPanel:
        view === "settings" ? () => ({ tab: this.tabs.get(view), projectId: this.projects.get(view) }) : undefined,
      disableStatsPolling: view === "settings",
    })
    if (this.remoteService) {
      provider.setRemoteService(this.remoteService)
    }
    provider.resolveWebviewPanel(panel)

    // Listen for closePanel from the webview (back button in panel mode)
    const closePanelDisposable = panel.webview.onDidReceiveMessage((msg) => {
      if (msg.type === "closePanel") {
        panel.dispose()
      }
    })

    // Navigate to the target view on every webviewReady (including after
    // "Developer: Reload Webviews" which re-creates the JS context).
    const readyDisposable = panel.webview.onDidReceiveMessage((msg) => {
      if (msg.type === "webviewReady") {
        const focus = this.focuses.get(view)
        this.focuses.delete(view)
        provider.postMessage({
          type: "navigate",
          view,
          tab: this.tabs.get(view),
          subtab: this.subtabs.get(view),
          focus,
          projectId: this.projects.get(view),
        })
      }
    })

    // Remember the active settings tab so it survives webview reloads.
    const tabDisposable = panel.webview.onDidReceiveMessage((msg) => {
      if (msg.type === "settingsTabChanged" && typeof msg.tab === "string") {
        this.tabs.set(view, msg.tab)
      }
    })

    this.panels.set(view, panel)
    this.providers.set(view, provider)

    const title = PANEL_TITLES[view]
    panel.onDidDispose(() => {
      console.log(`[Aura New] ${title} panel disposed`)
      closePanelDisposable.dispose()
      readyDisposable.dispose()
      tabDisposable.dispose()
      provider.dispose()
      this.panels.delete(view)
      this.providers.delete(view)
      this.tabs.delete(view)
      this.subtabs.delete(view)
      this.focuses.delete(view)
      this.projects.delete(view)
    })
  }

  setRemoteService(service: RemoteStatusService): void {
    this.remoteService = service
    // Apply to any existing providers
    for (const [, provider] of this.providers) {
      provider.setRemoteService(service)
    }
  }

  dispose(): void {
    for (const [, panel] of this.panels) {
      panel.dispose()
    }
    this.panels.clear()
    this.providers.clear()
    this.tabs.clear()
    this.subtabs.clear()
    this.focuses.clear()
    this.projects.clear()
  }
}
