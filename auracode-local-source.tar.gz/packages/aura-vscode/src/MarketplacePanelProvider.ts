import * as os from "os"
import * as vscode from "vscode"
import type { GlobalEvent, SessionStatus } from "@auracode/sdk/v2/client"
import { buildWebviewHtml, getWebviewFontSize } from "./utils"
import { watchFontSizeConfig } from "./aura-provider/font-size"
import { mapSSEEventToWebviewMessage, sameDirectory } from "./aura-provider-utils"
import { resolvePanelProjectDirectory } from "./project-directory"
import { seedSessionStatuses } from "./session-status"
import { type AuraConnectionService, ServerStartupError } from "./services/cli-backend"
import { MarketplaceService } from "./services/marketplace"
import {
  fetchMarketplaceData,
  installMarketplaceItem,
  removeMarketplaceItem,
  type MarketplaceActionContext,
} from "./services/marketplace/actions"
import type { InstallMarketplaceItemOptions, MarketplaceItem } from "./services/marketplace/types"
import { TelemetryProxy } from "./services/telemetry"
import { TelemetryEventName } from "./services/telemetry/types"
import { mcpAuth } from "./services/mcp-auth"
import { mcpRemoval } from "./services/mcp-removal"
import { notifySignInResult } from "./aura-provider/mcp-oauth"

interface MarketplaceMessage {
  type?: string
  mpItem?: MarketplaceItem
  mpInstallOptions?: InstallMarketplaceItemOptions
  url?: unknown
  event?: string
  properties?: Record<string, unknown>
  name?: string
  notify?: boolean
}

export class MarketplacePanelProvider implements vscode.Disposable {
  public static readonly viewType = "aura-code.new.marketplacePanel"

  private panel: vscode.WebviewPanel | undefined
  private project: string | null = null
  private ready = false
  private generation = 0
  private refresh: ReturnType<typeof setTimeout> | undefined
  private statuses = new Map<string, SessionStatus["type"]>()
  private pendingInstall: MarketplaceItem | undefined
  private pendingFocus: MarketplaceItem | undefined
  private disposables: vscode.Disposable[] = []
  private subscriptions: Array<() => void> = []
  private readonly marketplace = new MarketplaceService()
  private readonly extensionVersion =
    vscode.extensions.getExtension("auracode.aura-code")?.packageJSON?.version ?? "unknown"

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly connection: AuraConnectionService,
    private readonly context: vscode.ExtensionContext,
  ) {}

  private get marketplaceCtx(): MarketplaceActionContext {
    return { connection: this.connection, marketplace: this.marketplace, storage: this.context.globalStorageUri }
  }

  /**
   * `undefined` infers the project from the active editor or workspace,
   * while `null` intentionally disables project-scoped operations when no directory can be
   * selected safely, such as in an ambiguous multi-root workspace.
   */
  openPanel(directory?: string | null): void {
    const project = directory === undefined ? this.resolveProject() : directory
    if (this.panel) {
      this.setProjectDirectory(project)
      this.panel.reveal(vscode.ViewColumn.One)
      this.post({ type: "resetMarketplaceFilters" })
      this.scheduleRefresh()
      return
    }

    const panel = vscode.window.createWebviewPanel(
      MarketplacePanelProvider.viewType,
      "Aura Marketplace",
      vscode.ViewColumn.One,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [this.extensionUri],
      },
    )
    this.attach(panel, project)
  }

  deserializePanel(panel: vscode.WebviewPanel): void {
    this.attach(panel, this.resolveProject())
  }

  /** Open the panel and surface the install dialog for a specific item, project scope preselected. */
  openInstall(item: MarketplaceItem): void {
    this.openPanel()
    this.pendingInstall = item
    this.flushPendingInstall()
  }

  /** Open the panel focused on a specific item so it is easy to find. */
  focusItem(item: MarketplaceItem): void {
    this.openPanel()
    this.pendingFocus = item
    this.flushPendingFocus()
  }

  dispose(): void {
    this.panel?.dispose()
    this.cleanup()
  }

  private attach(panel: vscode.WebviewPanel, project: string | null): void {
    this.cleanup()
    this.panel = panel
    this.project = project
    this.ready = false
    panel.iconPath = {
      light: vscode.Uri.joinPath(this.extensionUri, "assets", "icons", "aura-light.svg"),
      dark: vscode.Uri.joinPath(this.extensionUri, "assets", "icons", "aura-dark.svg"),
    }
    panel.webview.options = {
      enableScripts: true,
      localResourceRoots: [this.extensionUri],
    }
    panel.webview.html = this.getHtml(panel.webview)

    this.disposables.push(
      panel.webview.onDidReceiveMessage((msg) => void this.handle(msg as MarketplaceMessage)),
      panel.onDidDispose(() => this.cleanup()),
      watchFontSizeConfig((msg) => this.post(msg)),
      vscode.extensions.onDidChange(() => this.scheduleRefresh()),
      vscode.workspace.onDidCreateFiles(() => this.scheduleRefresh()),
      vscode.workspace.onDidDeleteFiles(() => this.scheduleRefresh()),
      vscode.workspace.onDidRenameFiles(() => this.scheduleRefresh()),
    )
    this.subscriptions.push(
      this.connection.onStateChange((state, err) => {
        this.post({
          type: "connectionState",
          state,
          ...(err ? { error: err.message } : {}),
          ...(err instanceof ServerStartupError && {
            userMessage: err.userMessage,
            userDetails: err.userDetails,
          }),
        })
        if (state === "connected") void this.sync(false)
      }),
      this.connection.onLanguageChanged((locale) => this.post({ type: "languageChanged", locale })),
      this.connection.onEventFiltered(
        (event) => event.type === "session.status",
        (event) => {
          if (event.type === "session.status") this.handleStatus(event)
        },
      ),
      mcpAuth(this.connection).onChange((dir) => {
        if (dir === this.directory()) this.sendMcpAuthState()
      }),
      mcpRemoval(this.connection).on((event) => {
        if (!sameDirectory(event.directory, this.directory())) return
        if (event.phase === "removed" || event.phase === "installed") void this.fetchData()
      }),
    )
    void this.connect()
  }

  private cleanup(): void {
    if (this.refresh) clearTimeout(this.refresh)
    this.refresh = undefined
    for (const disposable of this.disposables) disposable.dispose()
    for (const unsubscribe of this.subscriptions) unsubscribe()
    this.disposables = []
    this.subscriptions = []
    this.panel = undefined
    this.ready = false
    this.generation++
    this.statuses.clear()
    this.pendingInstall = undefined
    this.pendingFocus = undefined
  }

  private async connect(): Promise<void> {
    try {
      await this.connection.connect(this.directory())
      await this.sync(this.statuses.size === 0)
    } catch (err) {
      this.post({
        type: "connectionState",
        state: "error",
        error: err instanceof Error ? err.message : String(err),
        ...(err instanceof ServerStartupError && {
          userMessage: err.userMessage,
          userDetails: err.userDetails,
        }),
      })
    }
  }

  private async sync(reconcile: boolean): Promise<void> {
    if (!this.ready) return
    const info = this.connection.getServerInfo()
    if (info) {
      const cfg = vscode.workspace.getConfiguration("aura-code.new")
      this.post({
        type: "ready",
        serverInfo: info,
        extensionVersion: this.extensionVersion,
        vscodeLanguage: vscode.env.language,
        languageOverride: cfg.get<string>("language"),
        fontSize: getWebviewFontSize(),
        workspaceDirectory: this.project ?? "",
      })
    }
    this.post({ type: "connectionState", state: this.connection.getConnectionState() })

    try {
      const client = this.connection.getClient()
      await seedSessionStatuses(client, this.directory(), this.statuses, (msg) => this.post(msg), reconcile)
    } catch (err) {
      console.warn("[Aura New] Marketplace session status sync failed:", err)
    }
  }

  private async handle(msg: MarketplaceMessage): Promise<void> {
    switch (msg.type) {
      case "webviewReady":
        this.ready = true
        if (this.connection.getConnectionState() === "connected") await this.sync(true)
        else await this.connect()
        await this.fetchData()
        this.flushPendingInstall()
        this.flushPendingFocus()
        return
      case "retryConnection":
        await this.connect()
        return
      case "fetchMarketplaceData":
        await this.fetchData()
        return
      case "installMarketplaceItem":
        if (msg.mpItem && msg.mpInstallOptions) await this.install(msg.mpItem, msg.mpInstallOptions)
        return
      case "removeInstalledMarketplaceItem":
        if (msg.mpItem) await this.remove(msg.mpItem, msg.mpInstallOptions?.target ?? "project")
        return
      case "dismissAgentMigrationBanner":
        await this.context.globalState.update("aura.agentMigrationBannerDismissed", true)
        return
      case "openExternal":
        this.openExternal(msg.url)
        return
      case "telemetry":
        if (msg.event) TelemetryProxy.capture(msg.event as TelemetryEventName, msg.properties)
        return
      case "requestMcpAuthState":
      case "signInMcp":
      case "cancelMcpSignIn":
        await this.handleMcpAuth(msg)
        return
    }
  }

  /** Dispatch the MCP OAuth sign-in messages, kept off `handle` to bound its complexity. */
  private async handleMcpAuth(msg: MarketplaceMessage): Promise<void> {
    if (msg.type === "requestMcpAuthState") {
      this.sendMcpAuthState()
      return
    }
    if (!msg.name) return
    if (msg.type === "signInMcp") {
      await this.signInMcp(msg.name, msg.notify !== false)
      return
    }
    await mcpAuth(this.connection).cancel(this.directory(), msg.name)
  }

  private sendMcpAuthState(): void {
    const dir = this.directory()
    const auth = mcpAuth(this.connection)
    this.post({ type: "mcpAuthState", directory: dir, needsAuth: auth.needsAuth(dir), busy: auth.busy(dir) })
  }

  private async signInMcp(name: string, notify: boolean): Promise<void> {
    const dir = this.directory()
    const result = await mcpAuth(this.connection).signIn(dir, name)
    this.post({ type: "mcpAuthResult", name, status: result.status, error: result.error })
    this.sendMcpAuthState()
    if (notify) notifySignInResult(name, result)
  }

  /** Ask the webview to open the install dialog for a queued suggestion, once it can receive it. */
  private flushPendingInstall(): void {
    if (!this.pendingInstall || !this.ready) return
    const item = this.pendingInstall
    this.pendingInstall = undefined
    this.post({ type: "openInstallModal", mpItem: item })
  }

  /** Ask the webview to focus a queued item, once it can receive it. */
  private flushPendingFocus(): void {
    if (!this.pendingFocus || !this.ready) return
    const item = this.pendingFocus
    this.pendingFocus = undefined
    this.post({ type: "focusMarketplaceItem", mpItem: item })
  }

  private scheduleRefresh(): void {
    if (!this.ready) return
    if (this.refresh) clearTimeout(this.refresh)
    this.refresh = setTimeout(() => {
      this.refresh = undefined
      void this.fetchData()
    }, 250)
  }

  private async fetchData(): Promise<void> {
    const generation = ++this.generation
    try {
      const project = this.project ?? undefined
      const data = await fetchMarketplaceData(this.marketplaceCtx, project, this.directory())
      if (generation !== this.generation) return
      const dismissed = this.context.globalState.get<boolean>("aura.agentMigrationBannerDismissed") ?? false
      this.post({ type: "marketplaceData", ...data, showAgentMigrationBanner: !dismissed })
    } catch (err) {
      if (generation !== this.generation) return
      const error = err instanceof Error ? err.message : String(err)
      console.warn("[Aura New] Marketplace data fetch failed:", err)
      this.post({
        type: "marketplaceData",
        marketplaceItems: [],
        marketplaceInstalledMetadata: { project: {}, global: {} },
        marketplaceRelevance: {},
        errors: [error],
      })
    }
  }

  private async install(item: MarketplaceItem, opts: InstallMarketplaceItemOptions): Promise<void> {
    const result = await installMarketplaceItem(
      this.marketplaceCtx,
      item,
      opts,
      this.project ?? undefined,
      this.directory(),
    )
    if (result.success) void vscode.window.showInformationMessage(`Successfully installed ${item.name}`)
    if (result.success && item.type === "mcp") {
      mcpRemoval(this.connection).emit({ directory: this.directory(), name: item.id, phase: "installed" })
    }
    const needsAuth =
      result.success && item.type === "mcp"
        ? (await mcpAuth(this.connection).refresh(this.directory())).includes(item.id)
        : false
    this.post({ type: "marketplaceInstallResult", ...result, needsAuth })
  }

  private async remove(item: MarketplaceItem, scope: "project" | "global"): Promise<void> {
    const directory = this.directory()
    const bus = item.type === "mcp" ? mcpRemoval(this.connection) : undefined
    bus?.emit({ directory, name: item.id, phase: "removing" })
    const result = await removeMarketplaceItem(
      this.marketplaceCtx,
      item,
      scope,
      this.project ?? undefined,
      this.directory(),
    )
    if (result.success) void vscode.window.showInformationMessage(`Successfully removed ${item.name}`)
    // Mirror install()'s auth refresh so a removed server's stale "needs
    // sign-in" state clears for every provider sharing this McpAuthService
    // (sidebar, chat tabs, Settings) via its onChange broadcast.
    if (result.success && item.type === "mcp") await mcpAuth(this.connection).refresh(directory)
    if (result.success) bus?.emit({ directory, name: item.id, phase: "removed" })
    bus?.emit({ directory, name: item.id, phase: "idle" })
    this.post({ type: "marketplaceRemoveResult", ...result })
  }

  private handleStatus(event: Extract<GlobalEvent["payload"], { type: "session.status" }>): void {
    const sid = event.properties.sessionID
    this.statuses.set(sid, event.properties.status.type)
    const msg = mapSSEEventToWebviewMessage(event, sid)
    if (msg) this.post(msg)
  }

  private setProjectDirectory(project: string | null): void {
    if (this.project === project) return
    this.generation++
    this.project = project
    this.post({ type: "workspaceDirectoryChanged", directory: project ?? "" })
  }

  private resolveProject(): string | null {
    const editor = vscode.window.activeTextEditor
    const active =
      editor?.document.uri.scheme === "file"
        ? vscode.workspace.getWorkspaceFolder(editor.document.uri)?.uri.fsPath
        : undefined
    return resolvePanelProjectDirectory(active, vscode.workspace.workspaceFolders)
  }

  private directory(): string {
    return this.project ?? vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? os.homedir()
  }

  private openExternal(raw: unknown): void {
    if (typeof raw !== "string") return
    const uri = vscode.Uri.parse(raw)
    if (uri.scheme !== "http" && uri.scheme !== "https") return
    void vscode.env.openExternal(uri)
  }

  private post(msg: unknown): void {
    if (!this.panel || !this.ready) return
    void this.panel.webview.postMessage(msg).then(undefined, (err) => {
      console.warn("[Aura New] Marketplace panel postMessage failed:", err)
    })
  }

  private getHtml(webview: vscode.Webview): string {
    return buildWebviewHtml(webview, {
      scriptUri: webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, "dist", "marketplace.js")),
      styleUri: webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, "dist", "marketplace.css")),
      iconsBaseUri: webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, "assets", "icons")),
      workerUri: webview.asWebviewUri(vscode.Uri.joinPath(this.extensionUri, "dist", "shiki-worker.js")),
      title: "Aura Marketplace",
      port: this.connection.getServerInfo()?.port,
    })
  }
}
