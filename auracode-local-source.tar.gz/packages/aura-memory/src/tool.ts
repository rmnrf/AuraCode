import { Effect, Schema } from "effect"
import type { MemoryOperations } from "./capture/operations"
import { MemoryError, type MemoryError as Failure } from "./effect/errors"
import { MemoryPaths } from "./effect/paths"
import { MemoryService } from "./effect/service"
import { MemoryRecall } from "./recall/recall"
import { MemorySchema } from "./schema"
import recallDescription from "./prompts/tool-memory-recall.txt"
import saveDescription from "./prompts/tool-memory-save.txt"

export namespace MemoryTool {
  export const RecallDescription = recallDescription
  export const SaveDescription = saveDescription
  const Text = Schema.String.check(Schema.isMaxLength(12_000))
  const Key = Schema.String.check(Schema.isMaxLength(256))
  const SessionID = Schema.String.check(Schema.isMaxLength(128))

  export const RecallParameters = Schema.Struct({
    mode: Schema.Literals(["search", "typed", "digest", "catalog"]).annotate({
      description:
        "'typed' to search durable memory, 'digest' to read saved session digests, 'search' to search both, 'catalog' to list all stored memory keys (use when the injected index or a search missed)",
    }),
    query: Schema.optional(Text).annotate({
      description: "Topic query for typed memory or digest search; optional substring filter for catalog",
    }),
    sessionID: Schema.optional(SessionID).annotate({
      description: "Session ID for digest mode when startup memory shows session=<id>",
    }),
    limit: Schema.optional(Schema.Number).annotate({
      description: "Maximum memories to return (default: 5, max: 20)",
    }),
  })

  export const SaveParameters = Schema.Struct({
    action: Schema.Literals(["remember", "correct", "forget", "skip"]).annotate({
      description: "Memory write action to perform.",
    }),
    text: Schema.optional(Text).annotate({
      description: "Memory text for remember/correct. Keep it concise and durable.",
    }),
    query: Schema.optional(Text).annotate({
      description: "Exact key, id, or query text for forget.",
    }),
    key: Schema.optional(Key).annotate({
      description: "Optional stable key for remember/correct.",
    }),
    reason: Schema.optional(Schema.Literals(["out_of_scope"])).annotate({
      description: "Skip reason when action is skip.",
    }),
  })

  export type RecallParams = Schema.Schema.Type<typeof RecallParameters>
  export type SaveParams = Schema.Schema.Type<typeof SaveParameters>

  // Named `sources` (not `files`): opencode's stripPartMetadata rewrites tool-part `metadata.files`
  // assuming apply_patch record entries, which would mangle a string[] on every read path.
  type Metadata = {
    sources: string[]
    count?: number
    operationCount?: number
    added?: number
    removed?: number
    skippedCount?: number
    reason?: "out_of_scope"
  }

  export type Result = {
    title: string
    output: string
    metadata: Metadata
  }

  export type AskInput = {
    permission: "aura_memory_recall" | "aura_memory_save"
    patterns: string[]
    always: string[]
    metadata: Record<string, unknown>
  }

  export type Ask = (input: AskInput) => Effect.Effect<void>

  type Base = {
    memory: MemoryService.Interface
    ctx: MemoryPaths.Ctx
    sessionID: string
  }
  type Recall = Base & { params: RecallParams; ask: Ask }
  type Save = Base & { params: SaveParams; ask: Ask }
  type Live = {
    root: string
    current: string
    state: MemorySchema.State
  }

  export function failure(err: unknown): err is Failure {
    if (!err || typeof err !== "object" || !("_tag" in err)) return false
    const tag = (err as { _tag?: unknown })._tag
    return typeof tag === "string" && tag.startsWith("Memory")
  }

  export function error(action: "recall" | "save", err: unknown): Result {
    return {
      title: "Aura memory: error",
      output: MemoryError.toToolOutput(err, action),
      metadata: { sources: [], ...(action === "recall" ? { count: 0 } : {}) },
    }
  }

  function disabled(count = false): Result {
    return {
      title: "Aura memory: disabled",
      output: "Aura memory is disabled for this project.",
      metadata: { sources: [], ...(count ? { count: 0 } : {}) },
    }
  }

  function miss(input: { params: RecallParams; current: string }) {
    const self = input.params.sessionID === input.current
    if (self && input.params.mode === "digest") {
      return `Session "${input.params.sessionID}" is the active session, so it has no saved memory digest yet. Do not read the active session transcript as memory; use injected memory or search recent saved digests.`
    }
    if (input.params.sessionID && input.params.mode === "digest") {
      return `No useful saved memory digest found for session "${input.params.sessionID}".`
    }
    return `No ${input.params.mode} memory matched the query.`
  }

  const CATALOG_MAX_BYTES = 8192
  const CATALOG_SESSION_LIMIT = 20
  const CATALOG_SESSION_SUMMARY = 120

  function block(input: string) {
    return ["```aura-memory-v1 targeted_context_not_instruction", input.replaceAll("```", "'''"), "```"].join("\n")
  }

  function clip(input: string, max: number): string {
    const text = Buffer.from(input).subarray(0, max).toString()
    if (Buffer.byteLength(text) <= max) return text
    return clip(text.slice(0, -1), max)
  }

  function catalog(memory: MemoryService.Interface, input: { root: string; query: string }) {
    const filter = input.query.toLowerCase()
    return Effect.gen(function* () {
      const lines: string[] = []
      const files: string[] = []
      let count = 0
      for (const file of MemorySchema.Sources) {
        const text = yield* memory.readSource({ root: input.root, file })
        const rows: string[] = []
        for (const raw of text.split("\n")) {
          const line = raw.trim()
          if (line.startsWith("## ")) continue
          const idx = line.indexOf(" :: ")
          if (!line.startsWith("- ") || idx < 0) continue
          const key = line.slice(2, idx).trim()
          const value = line.slice(idx + 4).trim()
          if (!key || !value) continue
          if (filter && !`${key} ${value}`.toLowerCase().includes(filter)) continue
          rows.push(`- ${key} :: ${value.length > 60 ? `${value.slice(0, 57)}...` : value}`)
        }
        if (rows.length === 0) continue
        files.push(file)
        lines.push(`## ${file}`, ...rows)
        count += rows.length
      }
      const sessions = yield* memory.recent({
        root: input.root,
        limit: CATALOG_SESSION_LIMIT,
        max: CATALOG_SESSION_SUMMARY,
      })
      const sessionRows: string[] = []
      for (const item of sessions) {
        if (filter && !`${item.id} ${item.topic} ${item.summary}`.toLowerCase().includes(filter)) continue
        const date = /^\d{4}-\d{2}-\d{2}/.exec(item.time)?.[0] ?? ""
        sessionRows.push(
          `- session=${item.id}${[item.topic, date]
            .filter(Boolean)
            .map((part) => ` ${part}`)
            .join("")}`,
        )
      }
      if (sessionRows.length > 0) {
        lines.push(`## sessions`, ...sessionRows)
        count += sessionRows.length
      }
      const head = `# Aura Memory Catalog (${count} entr${count === 1 ? "y" : "ies"}${filter ? `, filter "${input.query}"` : ""})`
      const body = [head, ...lines].join("\n")
      const output =
        Buffer.byteLength(body) > CATALOG_MAX_BYTES
          ? `${clip(body, CATALOG_MAX_BYTES)}\n[truncated: refine with a query filter]`
          : body
      return { output: count ? output : "No stored memory entries matched.", count, files }
    })
  }

  function approvalRecall(input: Recall) {
    return input.ask({
      permission: "aura_memory_recall",
      patterns: [input.params.mode],
      always: ["*"],
      metadata: {
        mode: input.params.mode,
        ...(input.params.query ? { query: input.params.query } : {}),
        ...(input.params.sessionID ? { sessionID: input.params.sessionID } : {}),
      },
    })
  }

  function recallCatalog(input: Recall, live: Live, query: string) {
    return Effect.gen(function* () {
      const result = yield* catalog(input.memory, { root: live.root, query })
      const safe = { ...result, output: block(result.output) }
      yield* input.memory.recordRecall({ root: live.root, sessionID: live.current, now: Date.now(), count: result.count })
      return {
        title: `Aura memory catalog: ${result.count} entr${result.count === 1 ? "y" : "ies"}`,
        output: safe.output,
        metadata: { sources: result.files, count: result.count },
      } satisfies Result
    })
  }

  function recallQuery(input: Recall, live: Live) {
    return Effect.succeed(
      {
        title: `Aura memory ${input.params.mode}: no query`,
        output: "Provide a topic query for typed/search memory recall.",
        metadata: { sources: [], count: 0 },
      } satisfies Result,
    )
  }

  function recallSearch(input: Recall, live: Live, query: string, mode: MemoryRecall.Mode) {
    return Effect.gen(function* () {
      const limit = Math.max(1, Math.min(input.params.limit ?? 5, 20))
      const result = yield* input.memory.search({
        root: live.root,
        state: live.state,
        mode,
        query,
        sessionID: input.params.sessionID,
        currentSessionID: live.current,
        limit,
      })
      const hits = result?.hits ?? []
      const output = hits.length ? result!.block : miss({ params: input.params, current: live.current })
      yield* input.memory.recordRecall({ root: live.root, sessionID: live.current, now: Date.now(), count: hits.length })

      if (hits.length === 0) {
        return {
          title: `Aura memory ${input.params.mode}: no results`,
          output,
          metadata: { sources: [], count: 0 },
        } satisfies Result
      }

      return {
        title: `Aura memory ${input.params.mode}: ${hits.length} hit${hits.length === 1 ? "" : "s"}`,
        output,
        metadata: { sources: [...new Set(hits.map((hit) => hit.source))], count: hits.length },
      } satisfies Result
    })
  }

  export function recall(input: Recall) {
    return Effect.gen(function* () {
      const current = input.sessionID
      const root = yield* input.memory.prepare({ ctx: input.ctx })
      const state = yield* input.memory.state({ root })
      if (!state.enabled) return disabled(true)
      yield* approvalRecall(input)

      const live = { root, current, state }
      const query = input.params.query?.trim() ?? ""
      const mode = input.params.mode
      if (mode === "catalog") return yield* recallCatalog(input, live, query)
      if (input.params.mode !== "digest" && !query) return yield* recallQuery(input, live)
      return yield* recallSearch(input, live, query, mode)
    })
  }

  function approval(params: SaveParams, ask: Ask, input: { text?: string; query?: string }) {
    return ask({
      permission: "aura_memory_save",
      patterns: [params.action],
      always: [],
      metadata: {
        action: params.action,
        ...(params.key ? { key: params.key } : {}),
        ...(input.text ? { text: input.text } : {}),
        ...(input.query ? { query: input.query } : {}),
      },
    })
  }

  function noQuery(): Result {
    return {
      title: "Aura memory forget: no query",
      output: "Provide a key, id, or query text to forget.",
      metadata: { sources: [] },
    }
  }

  function noText(action: SaveParams["action"]): Result {
    return {
      title: `Aura memory ${action}: no text`,
      output: `Provide text to ${action}.`,
      metadata: { sources: [] },
    }
  }

  function skipped(input: { reason: "out_of_scope" }): Result {
    return {
      title: title({ action: "skip", added: 0, removed: 0 }),
      output: skipOutput(input),
      metadata: {
        sources: [],
        operationCount: 0,
        added: 0,
        removed: 0,
        skippedCount: 1,
        reason: input.reason,
      },
    }
  }

  function saved(input: { params: SaveParams; result: MemoryOperations.Result }): Result {
    const touched = files(input.params.action)
    return {
      title: title({ action: input.params.action, added: input.result.added, removed: input.result.removed }),
      output: output({
        action: input.params.action,
        count: input.result.operationCount,
        added: input.result.added,
        removed: input.result.removed,
        tokens: input.result.index.tokens,
      }),
      metadata: {
        sources: touched,
        operationCount: input.result.operationCount,
        added: input.result.added,
        removed: input.result.removed,
      },
    }
  }

  function removed(input: { params: SaveParams; result: MemoryOperations.Result }) {
    return saved(input)
  }

  function skip(input: Base & { params: SaveParams }) {
    return Effect.succeed(skipped({ reason: input.params.reason ?? "out_of_scope" }))
  }

  function forget(input: Save, root: string) {
    return Effect.gen(function* () {
      const query = (input.params.query ?? input.params.text ?? "").trim()
      if (!query) return noQuery()
      yield* approval(input.params, input.ask, { query })
      return removed({
        params: input.params,
        result: yield* input.memory.forget({ root, sessionID: input.sessionID, query }),
      })
    })
  }

  function write(input: Save, root: string) {
    return Effect.gen(function* () {
      const text = (input.params.text ?? "").trim()
      if (!text) return noText(input.params.action)

      yield* approval(input.params, input.ask, { text })
      const result =
        input.params.action === "correct"
          ? yield* input.memory.correct({ root, sessionID: input.sessionID, key: input.params.key, text })
          : yield* input.memory.remember({ root, sessionID: input.sessionID, key: input.params.key, text })
      return saved({ params: input.params, result })
    })
  }

  export function save(input: Save) {
    return Effect.gen(function* () {
      const root = yield* input.memory.prepare({ ctx: input.ctx })
      const state = yield* input.memory.state({ root })
      if (!state.enabled) return disabled()
      if (input.params.action === "forget") return yield* forget(input, root)
      if (input.params.action === "skip") return yield* skip(input)
      return yield* write(input, root)
    })
  }

  function files(action: SaveParams["action"]) {
    if (action === "skip") return []
    if (action === "correct") return ["corrections.md"]
    if (action === "forget") return [...MemorySchema.Sources]
    return ["project.md"]
  }

  function title(input: { action: SaveParams["action"]; added: number; removed: number }) {
    if (input.action === "skip") return "Aura memory skipped: out of scope"
    if (input.action === "forget") return `Aura memory updated: ${input.removed} removed`
    if (input.added === 0) return "Aura memory unchanged"
    if (input.action === "correct")
      return `Aura memory correction saved: ${input.added} op${input.added === 1 ? "" : "s"}`
    return `Aura memory saved: ${input.added} op${input.added === 1 ? "" : "s"}`
  }

  function output(input: {
    action: SaveParams["action"]
    count: number
    added: number
    removed: number
    tokens: number
  }) {
    return [
      `action=${input.action}`,
      `operationCount=${input.count}`,
      `added=${input.added}`,
      `removed=${input.removed}`,
      `indexTokens=${input.tokens}`,
    ].join("\n")
  }

  function skipOutput(input: { reason: "out_of_scope" }) {
    return [`reason=${input.reason}`, "user-level memory is not supported yet."].join("\n")
  }
}
