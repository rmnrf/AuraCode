/** Wire contract for suppressible background-capture failures: guardReason emits this as the
 * `memory.error` reason, and every client surface (TUI toast filter, VS Code provider) matches
 * against this same constant rather than a local literal. Lives here (dependency-free module)
 * so clients can import it without pulling the capture pipeline into their bundles. */
export const TRANSIENT = "transient" as const

export namespace MemorySchema {
  export const VERSION = 1
  export const maxStoredDigestSummary = 4_000

  export const Sources = ["project.md", "environment.md", "corrections.md"] as const
  // Only the buckets MemoryTopics.assign can actually emit. Topics are assigned by rule (never by the
  // LLM) and never persisted with any other value, so unreachable buckets were trimmed rather than kept.
  export const Topics = ["project", "constraints", "environment", "corrections"] as const

  export type Source = (typeof Sources)[number]
  export type Topic = (typeof Topics)[number]

  export type Capture = {
    mode: "selective"
    turnClose: boolean
    explicit: boolean
    maxOpsPerRun: number
    minIntervalMs: number
    timeoutMs: number
  }

  export type Limits = {
    maxProjectIndexBytes: number
    maxSessionFiles: number
    maxRecentSessions: number
    maxConsolidationInputBytes: number
    maxLineChars: number
    maxSessionLineChars: number
  }

  export type Stats = {
    lastInjectedAt: number | null
    lastInjectedBytes: number
    lastInjectedTokens: number
    lastInjectedSessionID: string | null
    lastTypedConsolidationAt: number | null
    lastSessionSavedAt: number | null
    lastConsolidatedMessageID: string | null
    lastConsolidationCost: number
    lastConsolidationTokens: number
    lastOperationCount: number
    // Last active recall (model calling aura_memory_recall), for status surfaces.
    lastRecallAt: number | null
    lastRecallCount: number
    lastRecallSessionID: string | null
  }

  export type State = {
    version: 1
    enabled: boolean
    scope: "project"
    autoInject: boolean
    autoConsolidate: boolean
    verbose: boolean
    capture: Capture
    limits: Limits
    stats: Stats
  }

  const capture: Capture = {
    mode: "selective",
    turnClose: true,
    explicit: true,
    maxOpsPerRun: 16,
    minIntervalMs: 300_000,
    timeoutMs: 30_000,
  }

  const limits: Limits = {
    maxProjectIndexBytes: 8192,
    maxSessionFiles: 20,
    maxRecentSessions: 5,
    maxConsolidationInputBytes: 24_000,
    maxLineChars: 240,
    maxSessionLineChars: 480,
  }

  const stats: Stats = {
    lastInjectedAt: null,
    lastInjectedBytes: 0,
    lastInjectedTokens: 0,
    lastInjectedSessionID: null,
    lastTypedConsolidationAt: null,
    lastSessionSavedAt: null,
    lastConsolidatedMessageID: null,
    lastConsolidationCost: 0,
    lastConsolidationTokens: 0,
    lastOperationCount: 0,
    lastRecallAt: null,
    lastRecallCount: 0,
    lastRecallSessionID: null,
  }

  function rec(input: unknown): input is Record<string, unknown> {
    return typeof input === "object" && input !== null && !Array.isArray(input)
  }

  function bool(input: unknown, fallback: boolean) {
    return typeof input === "boolean" ? input : fallback
  }

  function num(input: unknown, fallback: number) {
    return typeof input === "number" && Number.isFinite(input) && input >= 0 ? input : fallback
  }

  function nullable(input: unknown, fallback: number | null) {
    if (input === null) return null
    return typeof input === "number" && Number.isFinite(input) && input >= 0 ? input : fallback
  }

  function str(input: unknown, fallback: string | null) {
    return input === null || typeof input === "string" ? input : fallback
  }

  export function topic(input: unknown): Topic | undefined {
    if (typeof input !== "string") return
    return (Topics as readonly string[]).includes(input) ? (input as Topic) : undefined
  }

  export function source(input: unknown): Source | undefined {
    if (typeof input !== "string") return
    return (Sources as readonly string[]).includes(input) ? (input as Source) : undefined
  }

  export function topics(input: unknown): Topic[] {
    if (!Array.isArray(input)) return []
    return [...new Set(input.flatMap((item) => topic(item) ?? []))].slice(0, 3)
  }

  export function kind(file: Source, section: string) {
    if (file === "corrections.md") return "correction"
    if (file === "environment.md") return "environment"
    const value = section.toLowerCase()
    if (value.includes("decision")) return "project_decision"
    if (value.includes("constraint")) return "project_constraint"
    if (value.includes("question")) return "open_question"
    return "project_fact"
  }

  export function recordKind(file: Source, section: string) {
    if (file === "corrections.md") return "CORRECTION"
    if (file === "environment.md") return "ENV"
    const value = section.toLowerCase()
    if (value.includes("decision")) return "PROJECT_DECISION"
    if (value.includes("constraint")) return "PROJECT_CONSTRAINT"
    if (value.includes("question")) return "INFERENCE"
    return "PROJECT_FACT"
  }

  export function create(): State {
    return {
      version: VERSION,
      enabled: false,
      scope: "project",
      autoInject: true,
      autoConsolidate: true,
      verbose: false,
      capture: { ...capture },
      limits: { ...limits },
      stats: { ...stats },
    }
  }

  export function missing(): State {
    return { ...create(), enabled: false }
  }

  export function persist(input: State) {
    return {
      version: input.version,
      enabled: input.enabled,
      scope: input.scope,
      autoInject: input.autoInject,
      autoConsolidate: input.autoConsolidate,
      verbose: input.verbose,
      capture: input.capture,
      stats: input.stats,
    }
  }

  export function parse(input: unknown): State {
    const base = create()
    if (!rec(input)) throw new SyntaxError("memory state must be an object")
    if (input.version !== undefined && input.version !== VERSION) {
      throw new SyntaxError(`unsupported memory state version: ${String(input.version)}`)
    }

    const cap = rec(input.capture) ? input.capture : {}
    const stat = rec(input.stats) ? input.stats : {}
    return {
      version: VERSION,
      enabled: bool(input.enabled, base.enabled),
      scope: "project",
      autoInject: true,
      autoConsolidate: bool(input.autoConsolidate, base.autoConsolidate),
      verbose: bool(input.verbose, base.verbose),
      capture: {
        mode: "selective",
        turnClose: bool(cap.turnClose, base.capture.turnClose),
        explicit: bool(cap.explicit, base.capture.explicit),
        maxOpsPerRun: Math.max(1, num(cap.maxOpsPerRun, base.capture.maxOpsPerRun)),
        // Floor both intervals to a small positive minimum: timeoutMs=0 would make every model call
        // abort instantly (permanent silent no-capture), and minIntervalMs=0 removes all throttling.
        minIntervalMs: Math.max(1000, num(cap.minIntervalMs, base.capture.minIntervalMs)),
        timeoutMs: Math.max(1000, num(cap.timeoutMs, base.capture.timeoutMs)),
      },
      // `limits` are hardcoded and never persisted (persist() omits them); always reset from defaults.
      limits: { ...base.limits },
      stats: {
        lastInjectedAt: nullable(stat.lastInjectedAt, base.stats.lastInjectedAt),
        lastInjectedBytes: num(stat.lastInjectedBytes, base.stats.lastInjectedBytes),
        lastInjectedTokens: num(stat.lastInjectedTokens, base.stats.lastInjectedTokens),
        lastInjectedSessionID: str(stat.lastInjectedSessionID, base.stats.lastInjectedSessionID),
        lastTypedConsolidationAt: nullable(stat.lastTypedConsolidationAt, base.stats.lastTypedConsolidationAt),
        lastSessionSavedAt: nullable(stat.lastSessionSavedAt, base.stats.lastSessionSavedAt),
        lastConsolidatedMessageID: str(stat.lastConsolidatedMessageID, base.stats.lastConsolidatedMessageID),
        lastConsolidationCost: num(stat.lastConsolidationCost, base.stats.lastConsolidationCost),
        lastConsolidationTokens: num(stat.lastConsolidationTokens, base.stats.lastConsolidationTokens),
        lastOperationCount: num(stat.lastOperationCount, base.stats.lastOperationCount),
        lastRecallAt: nullable(stat.lastRecallAt, base.stats.lastRecallAt),
        lastRecallCount: num(stat.lastRecallCount, base.stats.lastRecallCount),
        lastRecallSessionID: str(stat.lastRecallSessionID, base.stats.lastRecallSessionID),
      },
    }
  }
}
